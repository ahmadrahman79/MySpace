# Translok PPL Sakernas Agustus (pendataan)

Progress: Not Started
Activity: Administrasi
Note: No Notes
Status KipApp: Pending

OK 1 orang 1

- Nominatif
- FP
- Kuitansi-DOP
- KAK
- Surat Tugas
- SPPD dan Visum lampiran SPPD (Jika tidak absen)
- Visum (Jika Absen)

***8–18 Agustus 2026***

| **Nama** | **Laporan** | **Surat Tugas Pendataan** | **Visum** | **Kuitansi DOP** | **Dokumentasi** | **Keterangan** |
| --- | --- | --- | --- | --- | --- | --- |
| Luthfi Ramadhan |  | lengkap | lengkap |  |  |  |
| Husnul Hotimah |  | lengkap | lengkap |  |  |  |
| Fanny Amaranda |  | lengkap | lengkap |  |  |  |
| Jamalia |  | lengkap | lengkap |  |  |  |
| Fitri Sulastry |  |  |  |  |  | dititipkan dandy |
| Kamisah |  |  |  |  |  | dititipkan dandy |
| Irsanjani |  | lengkap | lengkap |  |  |  |
| Abdul Latif |  |  | lengkap |  |  |  |
| Muhlidin |  |  | lengkap |  |  |  |
| Juliati |  |  | lengkap |  |  |  |
| Bernadus Supranoto |  |  | lengkap |  |  |  |
| Kheisya Azzahra Jayani |  |  | lengkap |  |  |  |
| Azizi |  |  | pakai visum desa sengkubang |  |  |  |
| Aji Senjaya |  | lengkap | lengkap |  |  |  |
| Muhammad Akbar |  |  | pakai visum desa sengkubang |  |  |  |
| Riko Julianto |  | lengkap | lengkap |  |  |  |
| Mitasya Fitri Nainggolan |  | lengkap | lengkap |  |  |  |
| Anita Tri Andriani |  | lengkap | lengkap |  |  |  |
| Mega Wahyuni |  |  |  |  |  | sedang dikonfirmasi kak arin |
| Zulkifli |  | lengkap | lengkap |  |  |  |
| Wani Indriani |  |  |  |  |  | sedang dikonfirmasi kak arin |
| Sulastri |  |  | lengkap |  |  |  |
| Iga Losta |  | lengkap | lengkap |  |  |  |
| Muhammad Maulana Ihsan |  | lengkap | lengkap |  |  |  |