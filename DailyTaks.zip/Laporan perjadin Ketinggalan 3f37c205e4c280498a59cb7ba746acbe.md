# Laporan perjadin Ketinggalan

Progress: Not Started
Activity: Administrasi
Finish at: November 3, 2026
Note: No Notes
Status KipApp: Pending

Sakernas Mei (4 OK Pemutakhiran, 4 OK Pendataan) rentang tanggal 

![image.png](image.png)

Rentang cuti : 25-30 Mei

| Bulan Mei | Kegiatan | Hari | Catatan |
| --- | --- | --- | --- |
| 13 | Pemutakhiran Mempawah Hilir | Rabu |  |
| 18 | Pemutakhiran Mempawah Timur | Senin |  |
| 19 | Pemutakhiran Mempawah Timur | Selasa |  |
| 20 | Pendataan Mempawah Timur | Rabu |  |
| 21 | Pemutakhiran Toho | Kamis |  |
| 22 | Pendataan Toho | Jumat |  |
| 23 | Pendataan Mempawah Hilir | Sabtu |  |
|  | Pendataan Mempawah Hilir | Senin |  |

Sakernas Agustus (2 OK Pemutakhiran., 2 OK Pendataan)

| Tanggal | Kegiatan | Catatan |
| --- | --- | --- |
| 30 Juli | Pemutakhiran Sungai Pinyuh 1 |  |
| 31 Juli | Pemutakhiran Sungai Pinyuh 2 |  |
| 25 Agustus | Pendataan Sungai Pinyuh 1 |  |
| 2 September | Pendataan Sungai Pinyuh 2 |  |

Susenas September