# Rapikan dan lengkapi kekurangan SPJ

Progress: Not Started
Activity: Administrasi
Note: There Is a Note
Status KipApp: Pending

- [ ]  SPJ Translok mitra susenas maret
- [ ]  SPJ Honor Susenas Maret
- [ ]  SPJ Honor Seruti Tw 1
- [ ]  SPJ Translok PML Sakernas Februari
- [ ]  SPJ Translok PPL sakernas Februari