# Laporan perjadin Sakernas Agustus

Progress: Not Started
Activity: Administrasi
Note: No Notes
Status KipApp: Pending