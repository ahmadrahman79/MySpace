# Rangkuman Agenda 3

Last Edited Time: June 28, 2025 11:24 AM
Activity: Latsar
Created By: Ahmad Aulia

# Rangkuman 1

## 🧠 **MODUL 1: SMART ASN – Literasi Digital untuk ASN Cakap Digital**

**Tujuan Umum**: Meningkatkan kompetensi ASN agar mampu beradaptasi di era digital, serta berperan aktif dalam percepatan transformasi digital nasional.

### ✅ **1. Konsep Literasi Digital**

- Literasi digital mencakup **kemampuan mengakses, mengevaluasi, memahami, dan menciptakan informasi digital** secara etis dan aman.
- Indonesia menghadapi ancaman rendahnya literasi digital: hoaks, ujaran kebencian, radikalisme digital, penipuan, dll.

### ✅ **2. Pilar Literasi Digital**

Berdasarkan kerangka Kemenkominfo, ada **empat pilar**:

1. **Digital Skills**: Kemampuan teknis dalam menggunakan TIK.
2. **Digital Culture**: Berbudaya dalam dunia digital sesuai nilai Pancasila dan Bhinneka Tunggal Ika.
3. **Digital Ethics**: Menjunjung tinggi etika berinternet (netiquette).
4. **Digital Safety**: Kemampuan menjaga data dan keamanan digital.

### ✅ **3. Roadmap Literasi Digital Nasional 2021–2024**

- Disusun oleh Kominfo, Siberkreasi, dan Deloitte.
- Menekankan **kurikulum 4 area kompetensi** di atas.
- Target: mendorong masyarakat digital yang inklusif, cakap, aman, dan produktif.

### ✅ **4. Implikasi bagi ASN**

- ASN wajib bertransformasi secara digital, baik dalam pelayanan publik maupun koordinasi internal.
- Harus mampu **memanfaatkan teknologi** untuk mendukung tugas, termasuk menggunakan media sosial dengan bijak dan aman.
- Menjadi garda terdepan dalam **edukasi literasi digital** ke masyarakat.

---

## 🏛️ **MODUL 2: MANAJEMEN ASN – ASN sebagai Profesi dan Pelayan Publik**

**Tujuan Umum**: Memberikan pemahaman tentang sistem pengelolaan ASN sesuai UU No. 5 Tahun 2014 agar terbentuk ASN yang profesional, netral, berintegritas, dan melayani masyarakat secara prima.

### ✅ **1. Kedudukan dan Peran ASN**

- ASN terdiri dari **PNS** dan **PPPK**.
- ASN berkedudukan sebagai **aparatur negara**, bebas dari intervensi politik.
- Peran utama:
    1. **Pelaksana kebijakan publik**
    2. **Pelayan masyarakat**
    3. **Pemersatu bangsa**

### ✅ **2. Hak dan Kewajiban ASN**

- Hak: gaji, tunjangan, cuti, pengembangan kompetensi, jaminan sosial (pensiun/kematian), dll.
- Kewajiban: taat pada UUD 1945, menjaga NKRI, jujur, profesional, bersedia ditempatkan di seluruh wilayah Indonesia.

### ✅ **3. Kode Etik dan Perilaku ASN**

- Menjunjung nilai dasar ASN: jujur, akuntabel, disiplin, profesional.
- ASN wajib menjaga **martabat, rahasia negara, dan etika publik**.

### ✅ **4. Sistem Merit**

- Sistem merit = manajemen ASN berbasis **kualifikasi, kompetensi, dan kinerja**, bukan senioritas atau kedekatan politik.
- Mendorong karier terbuka (open career system) dan rekrutmen yang kompetitif.

### ✅ **5. Mekanisme Pengelolaan ASN**

- Meliputi manajemen PNS dan PPPK, jabatan pimpinan tinggi (JPT), serta penggunaan sistem informasi ASN dan penyelesaian sengketa kepegawaian.

---

## 🔄 **Keterkaitan Kedua Modul**

Kedua modul saling melengkapi:

- **SMART ASN** membekali ASN dengan **kompetensi digital** sebagai bagian dari profesionalisme baru.
- **Manajemen ASN** mengatur sistem dan nilai dasar ASN agar menjadi aparatur yang **efisien, netral, dan berintegritas**.
- Keduanya mendorong ASN menjadi **agen perubahan dan pelayan masyarakat** yang adaptif di era digital.

## ✅ Prinsip-Prinsip **Manajemen ASN**

Modul menjelaskan bahwa **Manajemen ASN** adalah kebijakan dan praktik pengelolaan ASN untuk mewujudkan aparatur yang profesional, berintegritas, dan berkinerja tinggi. Prinsip utamanya adalah:

### 1. **Sistem Merit**

Merupakan inti dari manajemen ASN, yaitu:

> “Kebijakan dan manajemen ASN yang berdasarkan pada kualifikasi, kompetensi, dan kinerja secara adil dan wajar, tanpa membedakan latar belakang politik, ras, agama, jenis kelamin, dan lainnya”.
> 

Sistem merit diterapkan pada seluruh aspek pengelolaan ASN, termasuk rekrutmen, promosi, mutasi, penilaian kinerja, dan pemberhentian.

### 2. **Profesionalisme**

ASN adalah profesi yang:

> “Harus memiliki nilai dasar, etika profesi, bebas dari intervensi politik, bersih dari praktik korupsi, kolusi, dan nepotisme”.
> 

### 3. **Akuntabilitas & Objektivitas**

Pengambilan keputusan harus berbasis data dan kinerja nyata, bukan hubungan pribadi atau senioritas:

> “Pengelolaan SDM didasarkan pada kemampuan dan kualifikasi, bukan pertimbangan subjektif seperti afiliasi politik atau senioritas”.
> 

### 4. **Transparansi & Keadilan**

Semua ASN memiliki kesempatan yang sama dalam pengembangan diri, promosi, dan evaluasi kinerja.

---

## ⭐ Prinsip-Prinsip **SMART ASN**

Walau istilah **SMART ASN (Solid, Melayani, Akuntabel, Responsif, Transformatif)** tidak secara eksplisit dijabarkan dalam modul ini, namun **nilai-nilai yang mendasarinya sangat sesuai** dengan penjabaran prinsip-prinsip manajemen ASN, misalnya:

- **Solid & Melayani** = ASN bekerja sama dan berorientasi pada kepentingan publik.
- **Akuntabel** = ASN bertanggung jawab atas tugas dan hasil kerjanya.
- **Responsif** = ASN mampu merespons kebutuhan instansi dan masyarakat secara cepat dan tepat.
- **Transformatif** = ASN terus mengembangkan diri dan menjadi motor perubahan.

---

## 🔍 Kesimpulan:

Modul “Manajemen ASN” menekankan pentingnya **sistem merit, profesionalisme, dan akuntabilitas**, yang sejalan dengan visi pembentukan **ASN yang SMART**. ASN tidak hanya dituntut untuk bekerja sesuai aturan, tetapi juga **mampu berinovasi, melayani, dan bertransformasi** untuk mendukung pelayanan publik yang lebih baik.

# Rangkuman 2 - Modul SMART ASN

## 🧠 **I. Tujuan Umum Modul SMART ASN**

Modul ini disusun untuk membekali ASN agar:

- Cakap menggunakan teknologi digital,
- Mampu beradaptasi dengan transformasi digital,
- Mewujudkan birokrasi yang efektif, efisien, dan akuntabel.

---

## 🌐 **II. Literasi Digital dan Transformasi ASN**

### 📌 A. Konsep Literasi Digital

Literasi digital bukan sekadar bisa mengoperasikan gawai, tetapi mencakup **kemampuan kritis, etis, dan produktif** dalam memanfaatkan teknologi digital.

### 🌟 Empat Kompetensi Utama Literasi Digital:

1. **Digital Skills** – keterampilan teknis menggunakan perangkat digital.
2. **Digital Safety** – kemampuan menjaga keamanan dan data pribadi.
3. **Digital Culture** – nilai kebangsaan & budaya dalam ruang digital.
4. **Digital Ethics** – perilaku etis, sopan, dan bertanggung jawab secara daring.

> 📍 Contoh di BPS Kabupaten/Kota:
> 
> 
> Petugas pengolah data menggunakan Google Drive & Zoom untuk koordinasi daring, namun tetap menjaga etika komunikasi, tidak menyebarkan data pribadi, dan menyesuaikan format file sesuai kebutuhan pengguna data.
> 

---

## 🧱 **III. Pilar Literasi Digital (Empat Pilar SMART ASN)**

### 1. **Etika Bermedia Digital**

🔹 Etika berinternet (netiquette): menghormati sesama, tidak menyebar hoaks, dan menjaga sopan santun di ruang digital.

> 🎯 Contoh: ASN BPS yang membuat grup WhatsApp mitra tetap menggunakan bahasa formal, tidak menyebarkan info belum terverifikasi, serta menjaga privasi peserta.
> 

---

### 2. **Budaya Bermedia Digital**

🔹 Menanamkan nilai **Pancasila dan Bhinneka Tunggal Ika** dalam aktivitas digital, termasuk menghargai keberagaman di ruang daring.

> 🎯 Contoh: Saat membagikan informasi kegiatan statistik, ASN BPS memperhatikan sensitivitas budaya lokal dan menyampaikan informasi dengan inklusif agar tidak memicu prasangka SARA.
> 

---

### 3. **Aman Bermedia Digital**

🔹 Mengamankan perangkat, akun, dan data pribadi dari ancaman siber (phishing, kebocoran data, dan lain-lain).

> 🎯 Contoh: ASN menggunakan password kuat untuk akun BOS/SIDATAS, tidak membuka link mencurigakan, dan tidak mengakses sistem melalui WiFi publik.
> 

---

### 4. **Cakap Bermedia Digital**

🔹 Mampu menggunakan perangkat lunak & aplikasi digital dengan efisien.

> 🎯 Contoh: ASN BPS kabupaten mampu membuat dashboard data survei menggunakan Google Data Studio atau Excel, mengunduh dan memfilter data SP2020/Sakernas melalui intranet BPS.
> 

---

## 🧩 **IV. Implementasi dan Dampak Literasi Digital**

Literasi digital diharapkan dapat menciptakan ASN yang:

- Adaptif dalam bekerja secara hybrid,
- Mampu menghindari konten negatif & disinformasi,
- Dapat berkolaborasi dan berinovasi secara digital.

> 🎯 Contoh nyata: ASN BPS menggunakan layanan digital untuk menyebarkan informasi statistik strategis melalui media sosial resmi kantor, serta mengedukasi mitra statistik soal pengisian CAPI secara daring.
> 

---

## 📊 **V. Contoh Nyata Program SMART ASN di Lingkungan BPS**

### 🔧 Kasus:

Misalnya, saat aplikasi FASIH error atau BOS lambat karena overload data, ASN yang **SMART** akan:

- Bersikap responsif mencari solusi,
- Berkoordinasi dengan rekan secara digital (Solid),
- Memberi laporan kendala ke admin pusat (Akuntabel),
- Mengusulkan peningkatan sistem berbasis pengalaman kerja (Transformatif).

---

## 🎯 **Kesimpulan: Mengapa SMART ASN Itu Penting**

Prinsip SMART ASN bukan sekadar jargon, melainkan:

- *Solid*: ASN bekerja kolaboratif, tidak ego sektoral.
- *Melayani*: ASN berorientasi pada kebutuhan publik.
- *Akuntabel*: ASN bertanggung jawab atas kinerjanya.
- *Responsif*: ASN cepat tanggap terhadap isu & tantangan.
- *Transformatif*: ASN terus belajar dan berinovasi.

> Dalam konteks BPS, ASN SMART akan berdampak pada:
> 
> - Data statistik lebih cepat diproses & disebarkan,
> - Pelayanan statistik sektoral lebih profesional,
> - Koordinasi internal dan eksternal lebih efisien.

# Rangkuman 3 - Modul Manajemen ASN

## 🏛️ I. **Kedudukan dan Peran ASN**

### 📌 **Kedudukan ASN**

ASN terdiri dari dua jenis:

1. **PNS** – Pegawai Negeri Sipil
2. **PPPK** – Pegawai Pemerintah dengan Perjanjian Kerja

ASN adalah **aparatur negara** yang menjalankan kebijakan publik, pelayan masyarakat, serta pemersatu bangsa. ASN harus **netral dari kepentingan politik**, dan ditempatkan di pusat, daerah, atau luar negeri.

> Contoh di BPS Kab/Kota:
> 
> 
> ASN BPS bertugas menjalankan program statistik nasional secara netral, seperti Sensus Penduduk dan Sakernas, tanpa terpengaruh tekanan politik lokal, meski bekerja di wilayah kabupaten/kota yang sarat kepentingan.
> 

---

## 📌 II. **Peran Utama ASN**

1. **Pelaksana kebijakan publik** – menjalankan program dan aturan sesuai ketentuan.
2. **Pelayan publik** – memberikan layanan statistik kepada pemerintah daerah, masyarakat, dan stakeholder.
3. **Pemersatu bangsa** – menjaga kesatuan melalui kehadiran ASN yang profesional di seluruh pelosok Indonesia.

> Contoh di BPS Kab/Kota:
> 
> 
> Petugas statistik hadir hingga ke wilayah perbatasan dan pulau terluar, memastikan data nasional tetap mencakup seluruh wilayah Indonesia – ini bentuk kontribusi ASN sebagai pemersatu bangsa.
> 

---

## ⚖️ III. **Hak dan Kewajiban ASN**

### ✅ **Hak ASN:**

- Gaji dan tunjangan
- Cuti
- Jaminan pensiun (PNS) / jaminan kerja (PPPK)
- Pengembangan kompetensi
- Perlindungan hukum, kesehatan, kecelakaan, kematian

### 🛠️ **Kewajiban ASN:**

- Setia pada Pancasila, UUD 1945, dan NKRI
- Menjalankan tugas secara jujur, disiplin, bertanggung jawab
- Menjaga kerahasiaan jabatan
- Bersedia ditempatkan di mana saja

> Contoh di BPS Kab/Kota:
> 
> 
> ASN yang ditempatkan di kecamatan terpencil tetap wajib menjalankan tugas pengolahan data survei, sekaligus mendapat hak atas tunjangan daerah dan perlindungan jika terjadi kecelakaan kerja di lapangan.
> 

---

## 📏 IV. **Kode Etik dan Perilaku ASN**

Kode etik ASN berfungsi sebagai panduan agar ASN:

- Jujur, disiplin, sopan
- Tidak menyalahgunakan jabatan
- Tidak menyebarkan informasi menyesatkan
- Mengutamakan kepentingan publik

> Contoh di BPS Kab/Kota:
> 
> 
> Petugas publikasi wajib menyampaikan data yang akurat dan menjawab permintaan informasi dari wartawan atau OPD dengan bahasa santun dan tidak menyesatkan, sesuai data rilis resmi.
> 

---

## 🧭 V. **Sistem Merit dalam Manajemen ASN**

### 📌 **Definisi Sistem Merit**

> “Sistem merit adalah kebijakan dan manajemen ASN yang berdasarkan pada kualifikasi, kompetensi, dan kinerja secara adil dan wajar, tanpa diskriminasi apa pun.”
> 

### Tujuan:

- Mendapatkan ASN yang berkualitas dan berintegritas
- Mewujudkan birokrasi profesional dan bersih
- Menjaga objektivitas dan akuntabilitas pengelolaan ASN

### Implementasi sistem merit meliputi:

- Rekrutmen terbuka (seperti CAT CPNS)
- Promosi dan mutasi berbasis kinerja dan kompetensi
- Penilaian kinerja yang obyektif
- Penghargaan dan sanksi berbasis prestasi dan pelanggaran

> Contoh di BPS Kab/Kota:
> 
> 
> Promosi seorang koordinator tim survei bukan karena senioritas, tapi karena konsisten menunjukkan kinerja tinggi dan mampu memimpin tim dalam survei Sakernas dan Susenas selama dua tahun terakhir.
> 

---

## ⚙️ VI. **Mekanisme Pengelolaan ASN**

### 📚 Komponen Pengelolaan ASN (Pasal 55 dan 93 UU ASN):

Untuk **PNS:**

- Penyusunan kebutuhan pegawai
- Pengadaan dan promosi
- Penilaian kinerja
- Pengembangan karier
- Penghargaan dan sanksi
- Jaminan pensiun & hari tua

Untuk **PPPK:**

- Pengadaan
- Penilaian kinerja
- Pengembangan kompetensi
- Pemutusan hubungan kerja
- Perlindungan

> Contoh di BPS Kab/Kota:
> 
> 
> BPS kabupaten menyusun kebutuhan formasi tenaga fungsional statistik berdasarkan beban kerja aktual dari survei dan sensus. Penempatan CPNS/PPPK dilakukan sesuai kebutuhan lapangan, bukan karena “hubungan dekat”.
> 

---

## 🛡️ VII. **Lembaga Penjamin Sistem Merit**

1. **Komisi ASN (KASN)**
    - Memantau pelaksanaan sistem merit dan memberi rekomendasi atas pelanggaran.
2. **Kementerian PAN-RB**
    - Memberikan kebijakan strategis dan evaluasi pelaksanaan UU ASN

---

## 💡 Penutup: Implikasi bagi ASN di BPS Kab/Kota

📌 **Mengapa ASN BPS harus memahami ini?**

- Agar bekerja profesional, melayani masyarakat dengan integritas, dan membangun kepercayaan publik terhadap data.
- ASN yang memahami sistem merit tahu bahwa **karier dan penghargaan ditentukan oleh kerja nyata**, bukan faktor subyektif.

📌 **Apa yang harus dilakukan?**

- Mengembangkan kompetensi statistik dan digital
- Menjalankan tugas dengan disiplin dan akuntabilitas
- Berani menolak praktik nepotisme atau penyimpangan etika
- Meningkatkan pelayanan data kepada pemda, media, dan masyarakat