# Pemeriksaan Dokumen Survei

Last Edited Time: August 30, 2026 4:39 PM
Activity: Sakernas
Created By: Ahmad Aulia

## Susenas Seruti

## Munawar

### *Minhat*

- *Minhat apakah tidak pernah potong rambut?*
    - *15k sebulan*
- *Minhat selain dari uang bisaroh, dia dapat mendapatan dari mana?*
    - *Dapat transfer dari anaknya per bulan 500k*
- *Apakah tidak membeli jenis cabai?*
    - *seminggu 1 ons cabai rawit dari menanam sendiri*
- *Apakah hanya memakan 1 jenis buah?*
    - *memang ga ada beli buah*
- *Apakah bumbu yang digunakan hanya garam, tidak ada bumbu lain?*
    - *pakai bumbu jadi misal 250 gr per 100 gr 10k*
- *Apakah dia tidak minum air kemasan sama sekali?*
    - *memang ga minum air*
- *Berapa bayar listrik bisanya?*
    - *50k per bulan 450 watt*
- *Apakah benar selama setahun tidak ke dokter untuk berobat?*
    - *rawat jalan ke dokter tidak pernah, tapi pernah rawat inap*
- *Apakah tidak pernah memberi ke ruta lain atau infak ke masjid?*
    - *per miinggu 5k*

### *Satro*

- *ART nya sekolah negeri atau swasta?*
    - *Fatrurahman Negeri, selainya swasta*
- *Tingkat pendidikan tertinggi Satro dan Istri apa?*
    - *ortu tidak sekolah*
- *Faturahman kerja di pabrik apa?*
    - *dia kerja di PT Unicoco*
- *Apakah benar selama seminggu terakhir tidak mengkonsumsi ayam?*
    - *memang ga ada*
- *Apakah benar hanya sayur kacang panjang dan kangkung yang dikonsumsi selama seminggu?*
    - *sesuai yg sudah ada di kuesioner*
- *Apakah benar tidak mengkonsumsi cabai?*
    - *Memang tidak konsumsi cabai karena tidak suka pedas*
- *Apakah benar tidak pernah potong rambut?*
    - *1 orang per bulan 1 kali per potong rambut 15k*
- *Apakah bener selama setahun tidak pernah berobat ke dokter?*
    - *Tidak pernah ke dokter, lebih memilih mengobati diri sendiri*
- *Apakah tidak pernah memberi makanan atau hasil panen ke tetangga?*
    - *memberi ke tetangga anggap aja memberi 5 piring seharga per piring 15k*

### *Saiful*

- *Apakah tidak pernah potong rambut selama sebulan?*
    - *1 orang per bulan 1 kali per potong rambut 15k*
- *Apakah tidak pernah berobat ke dokter selama setahun?*
    - *Memang ga ada berobat ke dokter. tapi membeli obat toko*
- *apa benar biaya obat yg dibeli tanpa resep dokter hanya 60k setahun?*
    - *udah diubah jadi 120k*
- *Apakah tidak ada pengeluaran untuk KB?*
    - *Memang ga ada*

## Sulis Tri

### *Lisa Halik*

- *Berapa biaya perawatan kecantikan?*
- *Apakah benar dalam setahun tidak membeli perabot dan perkakas rumah?*
- *Apakah benar selama setahun tidak ada pemeliharaan rumah?*
- *Ini beneran kulkas nya 5?*
- *apa benar di seruti perbaikan rumah 20 jt tapi di KP kosong*

### *Bun Kwet Tjong*

- *Apakah tidak ada pengeluaran perawatan rambut?*
- *Selama setahun apakah tidak pernah ke dokter?*

### Dany Haryanto

- apakah tidak pernah ke dokter?

# Podes

## Nanda Ariska

- **PARIT BANJAR**
    - apakah benar terdapat angkutan online yang menggunakan aplikasi?
- **PASIR**
    - Apakah benar jumlah keluarga pertanian tahun ini sama dengan tahun lalu?
- **PASIR PALEMBANG**
    - Waktu tempuh ke kantor camat tidak wajar
    - Waktu tempuh ke bupati camat tidak wajar
- **PASIR PANJANG**
    - Apakah benar Jumlah keluarga bukan pengguna listrik > 50 KK?
    - Jarak ke infra ekonomi terdekat bertambah >10 kali lipat padahal kemudahan sama atau lebih mudah (kemungkinan typo)
- **PENIBUNG**
    - apakah benar terdapat angkutan online yang menggunakan aplikasi?
- **PULAU PEDALAMAN**
    - Sinyal operator tidak ada. Harusnya ada meskipun tower di desa sebelah
- **SEJEGI**
    - Apakah benar Jarak ke kantor camat jauh lebih besar dari jarak ke kantor bupati/wali kota (4 kali lebih jauh)?
    - Apakah benar Jumlah keluarga bukan pengguna listrik > 50 KK?
    - apakah benar terdapat angkutan online yang menggunakan aplikasi?
    - Waktu tempuh ke kantor camat tidak wajar

## Yusron

- **KUALA SECAPAH**
    - Apakah benar jumlah keluarga pertanian tahun ini sama dengan tahun lalu?
    - Apakah benar Jumlah musyawarah desa/kelurahan > 15 selama tahun 2024 (takutnya rapat-rapat rutin dimasukkan)
- **PASIR WAN SALIM**
    - Apakah benar Kepala desa/lurah atau sekdes/seklur berjenis kelamin perempuan atau ada anggota BPD perempuan tetapi tidak ada keterlibatan penduduk perempuan dalam proses pengambilan keputusan?
- **SUNGAI BAKAU BESAR DARAT**
    - Apakah benar Kepala desa/lurah atau sekdes/seklur berjenis kelamin perempuan atau ada anggota BPD perempuan tetapi tidak ada keterlibatan penduduk perempuan dalam proses pengambilan keputusan?
- **SUNGAI BAKAU BESAR LAUT**
    - Apakah benar Tidak merasakan kelangkaan air karena kemarau panjang, tetapi ada bencana kekeringan?
    - Biaya ke kantor bupati lebih dari 1 juta
    - Biaya transportasi ke kantor camat lebih dari 10 juta
    - Jumlah musyawarah desa/kelurahan > 15 selama tahun 2024 (takutnya rapat-rapat rutin dimasukkan)
- 

# Sakernas Mei

## Wandi Safari

1. ABDUL HAMID
    1. ABDUL HAMID pada pekerjaan tambahannya apakah benar ada pembayaran dalam bentuk komisi? karena dia bekerja dalam sektor jasa, biasanya komisi diberikan dari persentase penjualan barang
    
2. AHMADI
    1. AHMADI komoditas mana yang memiliki waktu perawatan paling lama dalam seminggu terakhir? tambahkan penjelasan pada rincian 10.2
3. JUBRI
    1. apakah JUBRI bekerja membelah kayu dengan mesin atau gergaji manual? tambahkan di deskripsi rincian 10.2

### Handoko

**SAMBORA**

1. TOSIRAN
    1. TOSIRAN lebih sering mana antara jadi buruh tani atau buruh bangunan? diperbaiki deskripsi KBLI dan KBJI nya
2. TULIS
    1. TULIS isian 11.1 harusnya berkode 7
3. ROHYAT
    1. karena dia berjualan di depan sekolah harusnya isian 11.3 berkode 7
4. MAT SONGEP
    1. MAT SONGEP Apakah tambangnya ilegal atau legal? kalau ilegal harusnya isian 11.1 berkode 7
5. SUTIKNO
    1. SUTIKNO biasanya buruh tani komoditas apa yang sering? diperbaiki pada deskripsi pekerjaannya
6. MARSUNI
    1. MARSUNI pekerjaan tambahannya sebagai buruh tani komoditas apa yang sering? dilengkapi di deskripsi pekerjaan
    2. SUGIARTIN biasanya jadi buruh tani pada komoditas apa yang sering? dilengkapi dideskripsi pekerjaan

**BUMBUN**

1. DOYOT
    1. NIKO TISEN bekerja pada pertambangan mineral apa?
    2. NIKO TISEN isian 11.3 harusnya 5
    3. TEO DIUS isian 11.3 harusnya 5
2. RUSDI
    1. 10.2 dijelaskan lebih detail apa saja yg biasanya RUSDI di pekerjaannya. jika banyak kegiatan/serabutan jelaskan yang paling sering dilakukan dan komoditas pertanian yg sering dikerjakan apa
    2. 10.2 dijelaskan lebih detail apa saja yg biasanya JUNAIDAH di pekerjaannya. jika banyak kegiatan/serabutan jelaskan yang paling sering dilakukan dan komoditas pertanian yg sering dikerjakan apa
    3. PETRASIA perlu di cek lagi rincian 2.10. apakah benar masih bersekolah tapi status perkawinannya KAWIN
3. MANSAETUS HENDRO
    1. MANSAETUS HENDRO isian 11.3 harusnya kode 5
    2. 17.2 dijelaskan lebih detail apa saja yg biasanya MANSAETUS HENDRO di pekerjaan tambahannya. jika banyak kegiatan/serabutan jelaskan yang paling sering dilakukan dan komoditas pertanian yg sering dikerjakan apa
4. KAMALUDIN
    1. KAMALUDIN lebih sering mengoperasikan eskavator dipertambagan atau perkebunan? diperbaiki di rincian 10.2 dan 10.4
5. NATALIUS
    1. NATALIUS rincian 11.3 harusnya berkode 5
6. WILHELMUS ASMIANTO
    1. WILHELMUS ASMIANTO harunya 11.3 berkode 5
7. BERNANDUS
    1. isian 11.3 harusnya berkode 5
    2. Apakah benar BERNANDUS terdaftar sebagai anggota Serikat Pekerja? jika serikat pekerja yg dimaksud ada Koppri, maka itu tdk termasuk sebagai Serikat Pekerja

### RT 011 RW 002

1. NAWAHID
    1. Nawahid pada saat tidak bekerja mendapatkan uang untuk menghidupi keluarganya dari mana?
2. SAFI’EH
    1. Tempat kerja Safieh ada dimana jualannya?
3. AHMAD
    1. Kalo sedang tidak musim, apa kegaitan yang dilakukan AHMAD? jika ga melakukan apa pun bagaimana keluarganya hidup?
    2. Jawaban waktu ditanya alasan tidak mencari pekerjaan gimana?
    3. WAHYUDIAH apakah benar kerjanya ga pernah libur?
    4. WAHYUDIAH  Pendidikan yg telah ditamatkan harusnya sudah sesuai tingkatnya dengan pekerjaan pelayan rumah makan
    5. Apakah kegiatan sehari-hari IMAM dan usaha apa yang sedang dipersiapkan?
4. INDRA JAYA
    1. ARI MAULANA harusnya tingkat pendidikan yang dimiliki lebih tinggi dari pekerjaan yang dilakukan saat ini
5. MAT SARIP
    1. MAT SARIP harusnya tingkat pendidikan sudah sesuai dengan pekerjaan
    2. ISNIAWATI 11.3 harusnya kode 5
6. ACHMAD KODIR
    1. ACHMAD KODIR 20.4 harusnya 5

### RT 015 RW 006