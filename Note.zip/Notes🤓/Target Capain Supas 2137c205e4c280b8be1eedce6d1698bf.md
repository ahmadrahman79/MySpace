# Target Capain Supas

Last Edited Time: June 15, 2025 9:29 AM
Activity: Supas
Created By: Ahmad Aulia

## Target Pendataan

- 20 Juni 2025 --> 20%
- 4 Juli 2025 --> 50%
- 17 Juli 2025 --> 75%
- 29 Juli 2025 --> 100%\

## Target Pemutakhiran

Pemutakhiran dalam 1 SLS makasimal durasinya 5 hari