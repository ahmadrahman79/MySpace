# Link Pencari penyelesaian masalah Fasih

Last Edited Time: June 16, 2025 7:43 PM
Activity: Supas
Created By: Ahmad Aulia

[https://github.com/Rasyidarfan/RekapSupas](https://github.com/Rasyidarfan/RekapSupas)