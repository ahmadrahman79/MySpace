# Rekrutmen Mitra SE2026

Last Edited Time: May 29, 2026 12:37 PM
Activity: SE2026
Created By: Ahmad Aulia

### Monitoring Tahap Registrasi

[https://docs.google.com/spreadsheets/d/1O_NEyzTKGW0lwLhLFJr3Lpz6mTV1mVu2ZOag_hDA_u4/edit?usp=sharing](https://docs.google.com/spreadsheets/d/1O_NEyzTKGW0lwLhLFJr3Lpz6mTV1mVu2ZOag_hDA_u4/edit?usp=sharing)

### PJ Rekrutmen Kecamatan Mitra SE2026

[https://docs.google.com/spreadsheets/d/1ARKD2eQa6dzQe0e6IhdRf62yTJ07H_k2HBluZaxTakU/edit?gid=1519716137#gid=1519716137](https://docs.google.com/spreadsheets/d/1ARKD2eQa6dzQe0e6IhdRf62yTJ07H_k2HBluZaxTakU/edit?gid=1519716137#gid=1519716137)

### Catatan

- Pengumuman tahap registrasi 9 Mei