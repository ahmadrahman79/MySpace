# Draf Notulen Pertemuan Diperindagnaker

Last Edited Time: June 15, 2025 9:24 AM
Activity: Sektoral
Created By: Ahmad Aulia

# Catatan Aul

## Outline

1. Tujuan pembinaan : gimana caranya agar bisa fleksibel dalam pengolahan dan penyediaan data, terutama dari raw datanya

2. Pembuatan ARC dan syarat yg harus dipenuhi

3. pengolahan data

## Cara pengolahan data

1. data harus dikelola agar tidak mangkrak, harus dimutakhirkan. jangan sampek kita kasih data ke pimpinan atau pihak lain dalam bentuk raw data tanpa insight

2. Tutorial appsheet

# Catatan Mbk Safira

1. Persiapan permintaan mandiri dari dinas untuk tahun depan
2. Perbedaan data antar kementrian bukan ranah daerah tetapi bisa >>> Kolaborasi antar dinas di Kab Mempawah
(Perkuat raw data-) >>> inovasi murah
Pembuatan aplikasi tanpa coding >> north code
3. Aktualitas data >> pembuatan ARC harus ada SOP dan sudah disetujui oleh kepala dinas
4. Rekomendasi statistik >> profil data pedagang Kabupaten Mempawah, sebisa mungkin surat rekomendasi sebelum akhir bulan sudah selesai.