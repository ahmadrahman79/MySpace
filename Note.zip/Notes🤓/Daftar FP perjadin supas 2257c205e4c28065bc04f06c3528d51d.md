# Daftar FP perjadin supas

Last Edited Time: July 25, 2025 4:01 PM
Activity: Supas
Created By: Ahmad Aulia

Format nama FP di BOS : Transport Lokal *Pemeriksaan/Pengawasan Pemutakhiran/Pendataan/Kegiatan* Supas tanggal *26 dan 30 Juni* 2025 a.n *Arini Faurizah*

Transport Lokal Pemeriksaan Pemutakhiran Supas tanggal *26 dan 30 Juni* 2025 a.n **

---

akun POK perjadin pemutakhiran
GG 2905 BMA 006 005 A 524113 7

akun POK perjadin pendataan

GG 2905 BMA 006 005 A 524113 9

akun POK perjadin supervisi lapangan

GG 2905 BMA 006 052 A 524113 2

| **Nama** | **Sudah Konfirmasi** |
| --- | --- |
| Rifky | sudah konfirmasi |
| Ihza Fikri Zaki Karunia | sudah konfirmasi |
| Safira | sudah konfirmasi |
| Yulfi Ramanda | sudah konfirmasi |
| Wantri Mukti Lestari | sudah konfirmasi |
| Syarifah Apriani | sudah konfirmasi |

Transport Lokal Supervisi Pendataan Lapangan Supas tanggal 10 Juli 2025 a.n

| **Nama** | **Tanggal** | **Jenis Perjadin** | **Nomor FP** | **Status** | **Catatan** |
| --- | --- | --- | --- | --- | --- |
| Safira Nurrosyid | 26 dan 30 Juni | Pemeriksaan | FP-2025-428403-92800-434 | eror ga bisa di blok | Perlu revisi KAK |
| Rifky Mullah Syadriawan | 1 dan 2 Juli | Pemeriksaan | FP-2025-428403-92800-436 | absen sudah di blok | Perlu revisi KAK |
| Wantri Mukti Lestari | 3 Juli | Pemeriksaan | FP-2025-428403-92800-437 | absen sudah di blok | Perlu revisi KAK |
| Ihza Fikri Zaki Karunia | 14 Juli | Pemeriksaan | FP-2025-428403-92800-494 | absen sudah di blok |  |
| Wantri Mukti Lestari | 14 Juli | Pemeriksaa n | FP-2025-428403-92800-495 | absen sudah di blok | Perlu revisi KAK |
| Ihza Fikri Zaki Karunia | 30 Juni dan 7, 11 Juli | Pendataan | FP-2025-428403-92800-496 | eror ga bisa di blok | Perlu revisi KAK; tgl salah |
| Rifky Mullah Syadriawan | 24 Juni dan 3, 4, 7, 8, 9, 10, 11, 14, 15, 16, 17 Juli  | Pendataan | FP-2025-428403-92800-497 | absen sudah di blok |  |
| Safira Nurrosyid |  2, 7, 9, 10, 11, Juli  | Pendataan | FP-2025-428403-92800-498 | absen sudah di blok | Perlu revisi KAK |
| Wantri Mukti Lestari | 20, 23, 24, Juni dan 1, 2, 9, 11, 15, 17 Juli | Pendataan | FP-2025-428403-92800-499 | eror ga bisa di blok | Perlu revisi KAK |
| Yulfi Ramanda | 30 Juni dan 1, 8, 9, 10, 11, 15, 17, 18 Juli | Pendataan | FP-2025-428403-92800-500 | eror ga bisa di blok | Perlu revisi KAK |
| Syarifah Apriani | 1, 4, 9, 11, 15, 16 Juli | Pendataan | FP-2025-428403-92800-501 | absen sudah di blok | Perlu revisi KAK |
| Munawir | 10 Juli | Supervisi | FP-2025-428403-92800-502 | absen sudah di blok | Perlu revisi KAK |
| Arief Yuandi | 7, 10, 11 Juli | Supervisi | FP-2025-428403-92800-503 | absen sudah di blok | Perlu revisi KAK |
| Muhammad Adwin | 30 Juni | Supervisi | FP-2025-428403-92800-504 | eror ga bisa di blok | Perlu revisi KAK |
| Supandi | 4 dan 11 Juli | Supervisi | FP-2025-428403-92800-505 | absen sudah di blok | Perlu revisi KAK |
| Najia Helmiah | 1 Juli | Supervisi | FP-2025-428403-92800-506 | absen sudah di blok | Perlu revisi KAK |
| Syarifah Apriani | 7 dan 8 Juli  | Pemeriksaan | FP-2025-428403-92800-507 | absen sudah di blok |  |
| Ahmad Aulia Rahman | 2, 14, dan 17 Juli | Supervisi | FP-2025-428403-92800-508 | Dihapus | Perlu revisi KAK |
|  |  |  |  |  |  |

Ini gimana?

![image.png](Daftar%20FP%20perjadin%20supas/image.png)

![image.png](Daftar%20FP%20perjadin%20supas/image%201.png)

![image.png](Daftar%20FP%20perjadin%20supas/image%202.png)

![image.png](Daftar%20FP%20perjadin%20supas/image%203.png)