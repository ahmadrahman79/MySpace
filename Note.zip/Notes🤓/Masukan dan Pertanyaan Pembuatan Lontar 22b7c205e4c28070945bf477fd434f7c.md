# Masukan dan Pertanyaan Pembuatan Lontar

Last Edited Time: August 13, 2025 11:43 AM
Activity: Latsar
Created By: Ahmad Aulia

## Masukan

![image.png](Masukan%20dan%20Pertanyaan%20Pembuatan%20Lontar/image.png)

- Harusnya dilampiran itu katanya diktum ketiga bukan kedua
- Terbilang di nominatif harunya jumlah, bukan total besaran yang diterima
- Penambahan nominal pajak di nominatif honor
- Penambahan fitur untuk update rekening mitra/pegawai yang belum masuk database (*atur pakai spreadsheet*)
- Penambahan fitur untuk update rekining mitra/pegawai yang ganti (*via wa admin aja biar langsung ke database*)
- Fitur langsung generate Kuitansi dan DOP sekaligus
- gimana kuitansi dan DOP kalo seseorang perjadin dengan skema :
    - 1 tujuan dalam lebih dari 2 hari dan dalam 1 surat tugas
- pada kolom pajak, yang di tulis bukan persentase nya tapi nilai potongan pajaknya
- tambahkan sel hasil penjumlahhan total pajak

## Pertanyaan

1. 1 surat tugas berarti 1 kuitansi dan DOP kan? yaa
2. bagaimana dengan pajak? untuk nominatif apa itu?
3. Yg dibuat terbilang untuk nominatif yg ada pajak nya itu jumlah uang sebelum pajak atau setelah pajak?