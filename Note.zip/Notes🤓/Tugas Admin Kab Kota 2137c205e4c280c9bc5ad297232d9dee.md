# Tugas Admin Kab Kota

Last Edited Time: June 15, 2025 9:27 AM
Activity: Supas
Created By: Ahmad Aulia

1. Konfirmasi ke petugas jika ada muatan prelist yang berubah kurang lebih 20% dari prelist awal
2. Menerima laporan perubahan batas SLS
3. Konfirmasi ke petugas jika dalam 1 SLS tidak ada kematian sejak 1 Juli 2022
4. Memeriksa kembali Ruta hasil penarikan sampel oleh PML sebelum dialokasikan ke PPL (jumlah sampel, kejadian kematian dll)
5. Mengingatkan PPL pada saat mendekati DL target untuk mengsubmit isian yg sudah lengkap