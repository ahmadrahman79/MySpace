# Pendataan Lapangan SE2026

Last Edited Time: August 18, 2026 10:09 AM
Activity: SE2026
Created By: Ahmad Aulia

# TO DO LIST PJ KUDA

## *Sebelum Petugas Turun*

✅ Cek status perangkat dan pastikan akun FASIH semua PPL & PML sudah sinkron.
✅ Ingatkan PML untuk memeriksa kelengkapan atribut lapangan para PPL.
✅ Lakukan check-in pagi via WhatsApp Group khusus untuk memantau petugas di wilayah jauh.

## *Saat di Lapangan*

✅ Turun langsung dampingi petugas yang mengawas wilayah dekat (hari 1-2, hari 4-5)
✅ Susun jadwal kunjungan fisik ke wilayah jauh
✅ Respon cepat dan beri solusi jika ada kendala atau penolakan warga di lapangan.

## *Pemeriksaan Kualitas Data (Sore/Malam)*

✅ Periksa minimal 3 sampel hasil data milik setiap PPL (utamakan yang ada usaha).
✅ Periksa minimal 3 sampel hasil kerja pemeriksaan milik PML.
✅ Cari dan selesaikan temuan data yang anomali/tidak logis hari itu juga.
✅ Pantau progres harian petugas agar target selesai tepat waktu

## *Pelaporan & Evaluasi (Berkala)*

✅ Input hasil pemantauan harian ke Dashboard Provinsi Kalbar (link: [https://kuda.bpskalbar.id/alokasi](https://kuda.bpskalbar.id/alokasi)) sesuai pada email yg telah didaftarkan kemarin
✅ Kawal pelaksanaan Rapat Monev berkala pada Hari ke-3 dan Hari ke-6.
✅ Hadiri langsung Rapat Bersama seluruh PPL dan PML pada Hari ke-9.

# Pendataan UB

1. BANK BTN, PT <Ragi P. Aji Prasetyo>
    1. Berikan surat, suruh ngisi dan minta CP. kasih opsi bisa mengisi melalui PAPI
2. BANK RAKYAT INDONESIA (BRI) PT
    1. Berikan surat, suruh ngisi dan minta CP. kasih opsi bisa mengisi melalui PAPI
3. BANK TABUNGAN PENSIUNAN NASIONAL
    1. Berikan surat, suruh ngisi dan minta CP. kasih opsi bisa mengisi melalui PAPI

# Pertemuan Petugas

PENGUMUMAN: Pelaksanaan Rapat Pertemuan Tim SE2026

Yth. Seluruh Penanggung Jawab (PJ) Kuda SE2026,

Menindaklanjuti agenda kegiatan Sensus Ekonomi 2026 (SE2026), berikut adalah beberapa poin penting yang wajib diperhatikan dan segera ditindaklanjuti:

1. Batas Akhir Pelaksanaan Rapat Tim wajib diselesaikan paling lambat pada tanggal 30 Juni 2026. Mohon setiap tim segera menjadwalkan agenda masing-masing.
2. Bagi seluruh PJ Kuda, diharapkan untuk segera mengisikan tanggal pelaksanaan pertemuan tim, lokasi dan nama tempat pertemuan masing-masing melalui tautan berikut:
👉 [s.bps.go.id/kuda6104](http://s.bps.go.id/kuda6104)
3. Kelengkapan Administrasi: Daftar serta berkas administrasi yang wajib dilengkapi oleh PJ Kuda juga telah disediakan dan dapat diakses langsung pada tautan yang sama di atas.
4. Anggaran Konsumsi: Alokasi anggaran untuk keperluan konsumsi rapat ditetapkan sebesar Rp34.000,- per orang.

Demikian pengumuman ini disampaikan untuk menjadi perhatian dan dilaksanakan dengan penuh tanggung jawab demi kelancaran administrasi kita bersama. Atas kerja samanya, kami ucapkan terima kasih.

# Evaluasi Konsep dan Definisi

- Gagal paham konsep pengeluaran tahunan
- kalo ada transfer dari orang lain gimana pengisiannya
- konsep pengeluaran bulanan
- cara probing pengeluaran

# Keterangan Tidak Ditemukan

## RT 015 RW 008 Dusun Parit Banjar

- Keluarga pindah SLS karena cerai dan perkawinan
- Prelist salah memasukan KK
- KK banyak tidak dikenali

## RT 003 RW 002 kak Rika

- Banyak yg pindah karena nikah dan cerai
- Banyak yg kerja ke luar negeri
- Banyak yg gila jadi dirawat di rsj
- Banyak KK yg kerja ke Jawa dan Jakarta
- banyak BKU yg sebenarnya diluar SLS tapi masuk ke prelist sini
- KK yg cina banyak yg KK nya di RT ini tapi jarang pulang karena kerja atau punya tempat tinggal lain di wilayah lain. jadi disini jarang ditempati

# Revisit

## YANG BELUM SELESAI

1. ⁠golden empier(nd buka)
    1. Coba dikunjungi ke toko, kalo ga ada minta wa toko sebelahnya dan wawancara by phone
2. ⁠loundry xpress (datanya kurang)
    1. Coba minta karyawan telponkan pemiliknya, wawancara by phone
3. ⁠cv weka lestasi
    1. Coba minta ketemuan sama pemiliknya, jika menolak hubungi pak nawer
4. ⁠toko sepedah listrik(tutup)
    1. Coba dikunjungi ke toko, kalo ga ada minta wa toko sebelahnya dan wawancara by phone
5. ⁠rumah ruko besar(aneka berlian)
    1. Ambil datanya dari aneka berlian 50:50
6. ⁠toko tengah dekat momoyo(belum mau dicacah)
    1. Done
7. ⁠cahaya mandiri(katanya sudah didata didpn terminal)
    1. Ambil datanya dari usaha yang sudah didata
    2. Done
8. ⁠toko sepeda(nama owner belum ada)
    1. Done
    2. Toko Pramata Jaya Mempawah Jl Melati
9. ⁠toko welcome patoka(sabtu sore)
    1. Coba wawancara by phone
10. ADM
    1. Coba tanyakan ke karyawan dan telpon pemiliknya, lakukan wawancara by phone. kalo ga bisa hubungi pak nawer

## My Memory

- Nama Pemilik : Elisa
- NIK :
- NIB :
- Tahun berdiri : 2016
- Pekerja (cewe/cowo) : 1 cewe (pemilik)
- Gaji pekerja per bulan per orang
- Modal : 500k - 1jt habis 2-3 bulan
- Omset : 2-3 bulan 80k per tansaksi
- Status bangunan : milik sendiri warisan dari orang tua
- Luas bangunan : kurang lebih sama seperti ruko samping nya
- Jualannya online, toko nya cuma buat nyimpan barang