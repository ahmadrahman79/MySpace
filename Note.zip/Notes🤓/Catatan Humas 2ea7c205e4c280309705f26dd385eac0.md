# Catatan Humas

Last Edited Time: April 21, 2026 9:46 PM
Activity: Humas
Created By: Ahmad Aulia

# Link Kehumasan Dari Pusat

Hai - hai  teman2,, Selamat Tahun Baru 2026 🥳🥳.

Berikut beberapa tautan kegiatan kehumasan dari Humas BPS RI

1. Konten Medsos BPS 2026 [http://s.bps.go.id/kontenmedsos2026](http://s.bps.go.id/kontenmedsos2026)
2. Branding Medsos BPS 2026 [http://s.bps.go.id/brandingmedsos2026](http://s.bps.go.id/brandingmedsos2026)
3. Buku medsos: [http://s.bps.go.id/BukuMedsosBPS](http://s.bps.go.id/BukuMedsosBPS)
4. Orkestrasi komunikasi: [http://s.bps.go.id/OrkestrasiKomunikasi](http://s.bps.go.id/OrkestrasiKomunikasi)
5. Indonesia Raya, Mars Statistik terbaru: [s.bps.go.id/kelengkapanlagu](http://s.bps.go.id/kelengkapanlagu)
Terimakasih..
6. Drive Humas 2026 : [https://drive.google.com/drive/folders/1xLovL8ChmGp0IGncVYGVSPU3ryNBYbQC?usp=sharing](https://drive.google.com/drive/folders/1xLovL8ChmGp0IGncVYGVSPU3ryNBYbQC?usp=sharing)
7. Media publisitas SE 2026 : [https://drive.google.com/drive/folders/1TpG9ZdoUV6vkY_XixM32CsaUbezDm44G?usp=drive_link](https://drive.google.com/drive/folders/1TpG9ZdoUV6vkY_XixM32CsaUbezDm44G)

# Program Kerja Humas

## Reportase dan Konten Video

*Pelaksana : Sukma Andini, S.Tr.Stat. dan Vaniya Dewi Wulandari, A.Md.Stat.*

- Reportase pelatihan/briefing petugas pendataan secara offline
- Dokumentasi kegiatan internal kantor (Rapat, apel, jumat sehat dll)
- Konten fotografi
- Video reels publisitas SE2026
- Video tayang publisitas SE2026 untuk video tron

## Desain Grafis dan Editing

*Pelaksana : Budiman Aller Silaban, S.Tr.Stat. dan Safira Nurrosyid, S.Tr.Stat.*

- Poster PHBN
- Poster digital dan cetak untuk publikasi SE 2026
- Publikasi indikator strategis
- Desain banner
- Konten rilis publikasi
- Konten reportase kegiatan lapangan

## Komunikasi Eksternal

*Pelaksana : Ahmad Aulia Rahman, S.Tr.Stat.*

- Layanan Whatsapp dan DM Instagram
- Repost konten dari provinsi dan Pusat
- Pengumpulan dokumentasi kegiatan eksternal (untuk bahan laporan bulanan humas ke provinsi)

## Kegiatan Insedental

*Pelaksana : All*

# Teknis Pelaksanaan Umum

- Pembuatan konten melalui instagram mengikuti guide brand dari pusat
- Guide brand sudah disiapkan di akun canva kantor untuk langsung digunakan
- Jika membuat konten selain menggunakan canva, maka guide brand disesuaikan dengan software yang digunakan sendiri
- Jika menggunakan software selain canva untuk membuat konten grafis, hasil akhirnya harus tetap di upload di canva
- Semua desain dan konten yang berupa foto dikumpulkan menjadi 1 di penyimpanan canva sehingga dapat didelegasikan dengan mudah jika PJ sedang ada pekerjaan mendesak
- Untuk konten video disimpan dalam 1 drive sebagai arsip
- Konsep desain grafis yang digunakan adalah photo based, sehingga semua desain menggunakan foto sebagai objek utamanya, jangan menggunakan ilustrasi. Foto dapat diambil dari canva yang premium agar tidak terkena pelanggaran hak cipta
- Untuk konten yang diposting rutin seperti poster PHBN dan Konten rilis publikasi sebisa mungkin disiapkan maksimal H-1 bulan agar tidak keteteran dan menganisipasi telat upload
- Untuk pembagian tugas pada setiap program kerja adalah sebagai konseptor teknis dan manajer produksi konten terkait. Semua anggota tim humas akan tetap membantu pengerjaan program.

# Teknis Pelaksanaan Program

## Reportase dan Konten Video

*Pelaksana : Sukma Andini, S.Tr.Stat. dan Vaniya Dewi Wulandari, A.Md.Stat.*

- Reportase pelatihan/briefing petugas pendataan secara offline
    - Berkoordinasi dengan ketua tim kerja untuk menentukan tgl pelaksanaan pelatihan/briefing petugas agar tim humas dapat mempersiapkan jadwal peliputan
    - Posting konten di feed dan story instragram
    - Kegiatan yang diliput hanya kegiatan yang dilaksanakan secara offline tanpa memperhatikan lokasi
- Dokumentasi kegiatan internal kantor (Rapat, apel, jumat sehat dll)
    - Dokumentasi rapat dan apel dilakukan sebagai dokumentasi laporan Sakip dan ZI dan tidak di upload di instagram
    - Dokumentasi kegiatan resmi selain rapat dan apel seperti HSN, Jumat sehat dll di upload ke instagram dalam bentuk feed/reels dan story
    - File dokumentasi selain diupload ke instagram juga diupload ke drive terintegrasi dengan tim Sakip dan ZI untuk mempermudah interprobabilitas arsip
    - Integrasi dokumentasi dengan tim Sakip dan ZI berkoordinasi dengan bg rifky
- Konten fotografi
    - Konten fotografi berupa foto individu dengan baju navy BPS dan Baju SE, foto tim, foto ketua tim, dan foto se kantor
    - Perlu pengarsipan file foto individu yang menggunakan baju navy bps
    - Bahan mentah foto digunakan sebagai aset internal kantor untuk bahan pembuatan konten yang akan datang
    - Jika ada ide kreatif mengenai konten fotografi bisa dikoorinasikan di grup humas untuk dicarikan jadwal pembuatan konten dan mobilisasi talen
    - Konten fotografi di upload ke instargam sebagai feed dan story
- Video reels publisitas SE2026
    - Tujuannya untuk menyosialisasikan SE2026
    - Buat beberapa reels (sebelum bulan 31 Juli 2026)
    - DL upload semua reels mengenai pendataan lapangan SE2026 : Sebelum Juni 2026
    - Target : 1 bulan 2 Video Reels
    - Buat Akun tiktok
- Video tayang publisitas SE2026 untuk video tron
    - Kita buat sendiri 1 video. jika dapat jatah penayangan 2 video, pakai 1 dari pusat

## Desain Grafis dan Editing

*Pelaksana : Budiman Aller Silaban, S.Tr.Stat. dan Safira Nurrosyid, S.Tr.Stat.*

- Poster PHBN
    - Poster diupload ke instagram dalam bentuk feed dan story
    - Konsep menggunakan photos based
    - Menyesuaikan guide brand 2026
    - Sebisa mungkin konten dibuat maksimal H-1 bulan dan sudah tersedia di Canva. Buat file PHBN yang terpisah dengan file konten lain
    - Buat konten PHBN sesuai dengan daftar Konten PHBN yang sudah dibuat
- Poster digital dan cetak untuk publikasi SE 2026
    - Menyesuaikan kebutuhan dan strategi sosialisasi SE
- Publikasi indikator strategis
    - Publikasi kumpulan indikator strategis dilaksanakan setahun sekali. Sedangkan indikator strategis yang sifat nya rutin seperti bulanan/triwulanan buat cukup buat di story dan simpan di hightligh
- Desain banner
    - Menyesuaikan kebutuhan kantor
- Konten rilis publikasi
    - Konten berupa feed dan story
    - Sebisa mungkin semua publikasi dibuatkan konten rilisnya, terutama yg ARC
- Konten reportase kegiatan lapangan
    - Konten berupa kompilasi foto2 pendataan lapangan
    - Petugas di minta untuk dokumentasi seperti dokumentasi pencairan translok petugas. Bisa juga dokumentasi proses pendataan diambil oleh PML pada saat pengawasan
    - Jadwal upload menyesuaikan jadwal kegiatan
    - Perlu berkoordinasi dengan tim terkait untuk jadwal upload. Kalo terlalu pendek periode survei nya, buat konten setiap 6 bulan
    - Konten berupa feed instagram