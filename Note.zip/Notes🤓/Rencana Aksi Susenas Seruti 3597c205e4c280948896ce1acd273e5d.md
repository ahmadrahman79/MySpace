# Rencana Aksi Susenas Seruti

Last Edited Time: May 14, 2026 2:56 PM
Activity: Susenas-Seruti
Created By: Ahmad Aulia

# Serutii Triwulan 2 2026

## Rencana

- Honor larikan ke translok
- Rate buat 155k per orang
- Petugas nya dikasih tau kalo karena ini ada sensus jadi honor nya tidak bisa dibayarkan. sebagai gantinya nanti dapat translok. tapiii translok nya secara administratif hanya bisa di berikan ke 14 rekening. jadi nanti rekening yang dipake tolong ditransfer ke teman 1 tim nya. sebagai buktinya, nanti bukti  penerimaan dikirim ke kita
- Brieifing nya online karena ga ada anggaran
gimana kalo anggaran buat cetak dokumen ga cukup, kita jadi foto copy
- Pelatihan petugas Seruti 22 Mei 2026
- Seruti Tw 2 tidak ada perlengkapan petugas, jadi lanyard dan dll pakai punya susenas
- Surat tugas semua petugas dibuatkan, tapi yang digunakan untuk administrasi cuma koor nya aja. surat tugas yang digunakan untuk administrasi digunakan digunakan juga rekeningnya
Persiapan aplikasi untuk mempercepat pembuatan translok