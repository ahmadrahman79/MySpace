# Cleaning SE2026-Sosial Ekonomi

Last Edited Time: October 13, 2026 2:45 PM
Activity: SE2026
Created By: Ahmad Aulia

Daftar tabel/temuan prioritas:
A. Jenis Kelamin:

1. Tabel 27.Tabel Frekuensi Penduduk Menurut Jenis Kelamin (Versi Mikro - Jenis Kelamin Missing Value)
B. Umur:
2. Tabel 19. Jumlah Penduduk Menurut Umur Tunggal (Versi Mikro - Umur Null dan Di Luar Rentang 0-95)
C. NIK:
3. R27. Tabel jumlah penduduk menurut jumlah duplikasi NIK
4. R28. Tabel jumlah penduduk dengan jumlah digit nik anomali (!= 16 digit, bukan 7777, 9999, 8888)
5. R29. Tabel jumlah penduduk dengan dua digit pertama NIK 16 digit bukan kode provinsi
6. R30. Jumlah Penduduk dengan NIK yang Mengandung 6 Digit Kembar Berturut-turut Menurut Kabupaten Kota
D. No KK:
7. Tabel 11. Jumlah Penduduk yang mempunyai No KK tidak 16 digit
8. R1. Tabel jumlah keluarga berdasarkan duplikat nomor KK
9. R2. Tabel jumlah penduduk dengan length nomor KK bukan 4 digit (7777, 8888, atau 9999) atau 16 digit
10. R3. Tabel jumlah penduduk yang dua digit pertama nomor KK bukan kode provinsi (KK 16 digit)
11. R4. Tabel jumlah penduduk dengan nomor KK yang mengandung 6 digit kembar berturut-turut

E. Profesi:
Tabel 29. Tabel Frekuensi Profesi Pekerjaan Utama --> fokus ke 141 (presiden), 179 (wapres) , 040 (gubernur), 178 (wagub), 020 (bupati), 177 (wabup), 028 (camat), 046 (jaksa agung)

F. Listrik

1. R111. Keluarga dengan sumber penerangan utama bukan listrik, tetapi memiliki mobil
2. R116. Keluarga dengan Jumlah meteran listrik 1 dengan daya 450 watt, tetapi memiliki AC >2 unit Menurut Kabupaten/Kota