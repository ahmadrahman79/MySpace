# Pembekalan Pertama Penempatan Prov Kalimantan Barat

Last Edited Time: June 15, 2025 9:03 AM
Activity: Pembekalan Penempatan
Created By: Ahmad Aulia

1. Semua alokasj cpns dialokasikan dari menpan rb sesuai kebutuan organisasi
2. pelajari core value asn berakhlahk
3. perlu mempelajari substansi dari ZI dan WBK
4. kalo ada masalah dikantor misal ttg keputusan pimpinan kalo bisa diselesaikan di kantor sendiri, ga perlu pengaduan kepusat. komunikasikan masalah dng kepala kab atau kasubag umum, kalo ga bisa tanya pak udin lewat email
5. kalo kerja yg efektif, jangan merepotkan orang lain
6. pengaturan manajemen pegawai juga memperhatikan kinerja, bisa aja kalo kinerjanya bagus dipanggil ke pusat atau kementerian lain
7. belajar administrasi juga, jangan terlalu terpaku pada pekerjaan teknis
8. kemampuan/skill kepanitiaan untuk event seperti pelatihan petugas
9. data bps tdk mengeluarkan data by name by address
10. data yg dirilis bps hanya angkanya bukan identitas responden
11. jika perjadin ke prov, seragam nya menyesuaikan jadwal seragam prov
12. butuh ketelitian untuk mengolah data survey
13. pengalaman lapangan diperlukan untuk pengolahan data, seperti validasi. selain itu pengalaman lapangan diperlukan untuk analisis data kyak anomali dll
14. sakernas 2025 dilakukan 4 kali
15. kalo banyak kerjasn, kerjakan aja, kalo capek harus istirahat, kalo sakit berhenti dulu, baru kalo dah sembuh dilanjutkan
16. sabar aja kalo masuk tim distribusi dan jasa
17. anomali data distribusi harus bisa dijelaskan fenomena nya
18. dalam menghitung data perlu sense of data, agar angka yang djhasilkan konsisten dan tidak anomali