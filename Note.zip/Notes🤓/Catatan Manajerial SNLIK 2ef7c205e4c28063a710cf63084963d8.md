# Catatan Manajerial SNLIK

Last Edited Time: January 25, 2026 8:07 PM
Activity: SNLIK
Created By: Ahmad Aulia

### Bahan Rapat Persiapan SNLIK :

[http://s.bps.go.id/Materi_Rakorda_SNLIK2026_Provinsi_Kalbar](http://s.bps.go.id/Materi_Rakorda_SNLIK2026_Provinsi_Kalbar)

### Link Zoom Persiapan SNLIK 22 Januari 2026

[http://s.bps.go.id/persiapansnlik61](http://s.bps.go.id/persiapansnlik61)

## Catatan Administrasi

- Laporan translok petugas pakai laporan translok mail merge tapi format dari provinsi