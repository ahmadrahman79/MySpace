# Sprint Planning

Last Edited Time: June 15, 2025 9:01 AM
Activity: Seruti Tw 2 & 4
Created By: Ahmad Aulia

# Sprint Goal

What will we accomplish over the course of the sprint?

- 

# Sprint Backlog

List of backlog items that we're committed to work on during the sprint.

- 

# Team & Roles

- 

# Notes

-