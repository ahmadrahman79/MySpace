# Catatan Pelatihan Inda Sakernas

Last Edited Time: July 9, 2026 3:14 PM
Activity: Sakernas
Created By: Ahmad Aulia

# Sakernas Februari

### Teknis Pemutakhiran

- Keluarga mengacu pada KK. jadi misalnya ada anak yg sudah menikah tapi KK nya gabung dengan istrinya, maka tetep dihitung sebagai 1 KK
- Kalo ada keluarga yg terdiri dari ayah ibu dan anak, nah anaknya dah nikah, tapi belum pecah KK atau pasangannya belum masuk KK, maka pasangannya ini dianggap sebagai keluarga sendiri.
- Jika ada keluarga baru yg tinggal dengan keluarga yang sudah ada di prelist maka tulisakn nomor bangunan sama dng keluarga tempat dia tinggal
- Jika ada keluarga yang tinggal dibagunan baru, maka beri nomor bangunan malnjutkan nomor bangunan yang paling besar
- Penarikan sampel hanya dapat dilakukan sekali
- Penarikan sampel rumah tangga dilakukan oleh admin fasih
- Hasil pemutakhiran ole PPL harus di approve ileh PML sebelum dilakukan penarikan sampel
- Jangan sampai salah cakupan SLS
- Jangan sampai ada keluarga yg terlewat di lapangan, karena hasil pemutakhiran SLS pada 2026 akan digunakan dasar pada sakernas 2027-2028
- Jika ada perbedaan nama dengan prelist, maka keluarga tetap dianggap ditemukan dan kepala keluarganya tetap.
- Jika ada kepala keluarga meninggal atau pindah SLS atau pecah keluarga misalnya krn percereaian dan struktur keluarganya tetap, maka status keluarga tetap ditemukan, tapi ada perubahan kepala keluarga.
- Keluarga baru yang ditemukan walaupun rutanya sama tetap di tambahkan sebagai keluarga baru. jadi nanti dia no urut ruta, no bangunan isi nya sama dengan ruta induk. sedangkan untuk nama KRT tdk di isi krn masih merujuk pada ruta induknya

### Manajemen

- Perlu adanya tanda pengenal
- Gunakan peta WS kosongan
- Memastikan infrastruktur digital sudah siap dan semua petugas bisa mengaksesnya
- Perlu adanya brieing strategi yang detail untuk petugas
- Setelah penarikan sampel oleh admin kabupaten baru akan muncul DSRT

# Sakernas Agustus

## Pemutakhiran

- Perlu memahami ulang PPT pemutakhiran, karena ada perubahan cara kerja karena ada SLS panel dan komplemen
- Untuk rumah tangga baru rincian 9. Identifikasi KK/KRT pasti langsung kode 2. Kepala Rumah Tangga (KRT)
- Pada SLS panel, sampel Ruta ditarik berdasarkan hasil pemutakhiran, bukan berdasarkan hasil sampel sebelumnya
- Untuk penentuan keluarga prioritas menggunakan pendekatan KK, baru kalo ga ada KK menggunakan ikatan perkawinan meskipun perkawinanannya tidak tercatat secara resmi oleh negara
- Untuk perubahan batas SLS hanya diakomodir untuk SLS komplemen, untuk SLS panel bulan februari dan mei tidak dapat diubah lagi. jadi cakupannya sudah fix
    
    

## Pendataan

- pada modul 9, responden yang bekerja pada sektor pertanian yang menanam beberapa jenis komoditas tetap dianggap memiliki 1 pekerjaan
- Pertanyaan pada modul 9 terkait pada pekerjaan yang sudah tercatat pada modul 7 atau 8
- Modul 10 digunakan untuk mencatat karakteristik pekerjaan utama meskipun pekerjaan utamanya sedang sementara tidak bekerja
- Pekerjaan utama ditentukan berdasarkan waktu biasanya yang paling banyak digunakan, kalo waktunya sama, perhitungkan pendapatan biasanya yang paling besar, kalo pendapatannya sama gunakan preferensi responden
- 10.2 keterangan ditulis selengkap-lengkapnya menggunakan bahasa indonesia
- Magang dibayar yang dimaksud dalam sakernas adalah magang yang tidak termasuk dalam kurikulum sekolah. jadi beneran intern yang memang diselenggarakan oleh entitas non pendidikan formal
- Pertanyaan mengenai kesesuaian pendidikan dengan pekerjaan adalah berdasarkan persepsi responden
- Pekerja yang dibayar yang dipekerjakan pada 10.11 maksudnya adalah karyawan tetap, dia kontraknya minimal 1 bulan. bukan karyawan parttime juga
- Transportasi yang digunakan untuk bekerja adalahh kendaraan yang biasanya digunakan
- Pekerjaan musiman itu ada pola nya. jadi dia tidak bekerja sesuai dengan pola. biasanya pola jangka panjang yang bisa sampai berbulan-bulan, bukan yang jangka pendek
- Cedera atau kondisi yang membahayakan kesehatan yang dimaksud adalah cedera yang terjadi disebabkan langsung karena pekerjaan dan berada dalam jam kerja
- pada pertanyaan 14.1 ditanyakan untuk mengetahui apakah perusahaan responden memberikan jaminan sosial atau jaminan ketenagakerjaan. jadi yang dinilai adalah kebijakan perusahaannya. jadi meskipun responden tidak pernah menggunakan fasilitas jaminan sosial dan ketenagakerjaan jika perusahaan memberikan fasilitas itu, maka dianggap IYA
- pada pertanyaan 14.2 berisi jawaban IYA apabila jaminan sosial dibayar sendiri sepenuh nya oleh responden. entah itu pakai uang responden sendiri atau uang keluarganya. yang jelas berisi jawaban IYA kalo tidak ada kontribusi sama sekali dari perusahaan untuk membayar premi asuransi
- Pekerjaan utama dan tambahan ditentukan berdasarkan pekerjaan yang biasanya dilakukan. jadi yg biasanya paling lama dilakukan jadi pekerjaan utama
- Ketua RT, RW, kepala Desa, Kepala Dusun KBLI 84112 KBJI 1113. dia KBJI nya tinggi, manager, tapi pendapatannya kecil, jadi dia akan jaadi anomali. ntar dikasih penjelasan aja di catatan
- Untuk sektor pemerintahan, KBLI