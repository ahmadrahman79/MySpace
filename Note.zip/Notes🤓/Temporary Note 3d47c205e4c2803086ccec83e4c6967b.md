# Temporary Note

Last Edited Time: September 15, 2026 9:16 AM
Activity: Random
Created By: Ahmad Aulia

# Teknis (Dikerjakan hari ini)

1. Penyelesaiaan SE
    1. ~~Cek usaha yg di info mbak sarah~~
    2. ~~Hapus assigment yg di chat kak ratna~~
    3. ~~haspu assigment yg di chat pak Yudi~~
    4. ~~Merapikan dokumen K1 asrama Asisi~~
    5. ~~Anomali SE~~
2. ~~Pengawasan dan pemeriksaan Susenas Seruti~~

# Administrasi

1. Translok PPL Sakernas Mei
2. Translok PPL Sakernas Agustus
3. SPJ Pertemuan 3 Sungai Pinyuh
4. Translok lain yg belum terbayar
5. SPJ perjadin SE penyisiran
6. Rapikan dokumen SPJ Bulan Januari-Maret