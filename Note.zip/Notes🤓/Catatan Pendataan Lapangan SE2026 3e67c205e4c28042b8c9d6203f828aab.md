# Catatan Pendataan Lapangan SE2026

Last Edited Time: September 25, 2026 7:19 AM
Activity: SE2026
Created By: Ahmad Aulia

# Template

RT 009 RW 05

- Usaha :
- Nama :
- no HP :
- NIK :
- Usia :
- Karyawan L : … P : …
- Modal :
- Aset :
- Luas :
- Kotor :
- Tahun :