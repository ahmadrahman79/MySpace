# Publisitas dan Humas SE2026

Last Edited Time: June 28, 2026 2:28 PM
Activity: SE2026
Created By: Ahmad Aulia

# Publisitas Luar Ruangan

Rekap rencana dan alokasi

[https://docs.google.com/spreadsheets/d/1supbb-bcyDS_wLU52Ulj-E626Wb60K9ax03uAVZnEl0/edit?usp=sharing](https://docs.google.com/spreadsheets/d/1supbb-bcyDS_wLU52Ulj-E626Wb60K9ax03uAVZnEl0/edit?usp=sharing)

# VIDEO DUKUNGAN TOKOH

Template Narasi Testimoni : https://drive.google.com/drive/folders/1_adkAWp7p6_G9vtogZXYk_pTHlNkDwgn?usp=sharing

List link video dukungan kab kota kalbar (ga tau ini apa) : https://docs.google.com/spreadsheets/d/1y-HtaG5Pn62dbJImTXQJo4jp2tXzpZdq-Vz-_qMAYiU/edit?usp=sharing

# Tim Humas Pelatihan

| **Gelombang I** | **Tanggal 3-5 Juni 2026** |  |  |
| --- | --- | --- | --- |
|  | **Kelas** | **Nama** | **Lokasi** |
|  | A | Briggita Vaya Difa (MK) **(Dokumentasi)** | Wisata Nusantara Aula Besar |
|  | A | Firmansyah | Wisata Nusantara Aula Besar |
|  | B | Rifky Mullah Syadriawan (MK) | Wisata Nusantara Aula Kecil |
|  | B | Muhammad Adwin | Wisata Nusantara Aula Kecil |
|  | A dan B | Sukma Andini (MC) | Wisata Nusantara |
|  | A dan B | Ahmad Aulia Rahman (Doa) | Wisata Nusantara |
|  | C | Arsita Indah Wahyuni (MK) | K-Tamb Aula Atas |
|  | C | Syarifah Apriani | K-Tamb Aula Atas |
|  | D | Clara D.V.L (MK) | K-Tamb Aula Bawah |
|  | D | Vaniya D.W **(Dokumentasi)** | K-Tamb Aula Bawah dan Atas |
|  | E | Listio Jati Nandhiko (MK) **(Dokumentasi)** | Patoka Pinyuh |
|  | E | Yulfi Ramanda | Patoka Pinyuh |
| **Gelombang II** | **Tanggal 10-12 Juni 2026** |  |  |
|  | F | Arini Faurizah (MK) **(Dokumentasi)** | Wisata Nusantara Aula Besar |
|  | F | Abdul Karim | Wisata Nusantara Aula Besar |
|  | G | Sukma Andini (MK) **(Dokumentasi)** | Wisata Nusantara Aula Kecil |
|  | G | Wantri Mukti | Wisata Nusantara Aula Kecil |
|  | H | Ahmad Aulia Rahman (MK) **(Dokumentasi)** | K-Tamb Aula Atas |
|  | H | Haddad Rifky | K-Tamb Aula Atas |
|  | I | Akma BJ (MK) **(Dokumentasi)** | K-Tamb Aula Bawah |
|  | I | M Syihabuddin Alhaq | K-Tamb Aula Bawah |

# Susunan Acara

- Indonesia Raya
- Doa
- Laporan Panitia
- Sambutan Kepala
- Pemasangan rompi dan id card
- Penutupan

# Ngibar PTSP

- Dokumentasi kegiatan berupa SS zoom dan foto dan video BTS
- VBG
- Bahan paparan SE2026 yang relevan terkait ngibar. kalo bisa kasih tau pentingnya ngibar bagi perusahaan. mungkin lebih ke apa sii manfaat SE untuk perusahaan
- Zoom
- Hubungi operator MCC agar sinkron antara zoom dengan mikrofon
- Slide show materi

# Pembukaan Pelatihan Petugas Gelombang 2

- MC : Kak Gita
- Operator :
    - Wisnus : Aul
    - Ktamb : Hadad, Syihab, Sarah, Najia (untuk 2 kelas)
- Penyematan : Ninda dan Nisa
- Perkap : bg Rifky
- Doa : Listio
- Dokumentasi : Vaniya dan Arin
- PJ Bahan paparan : Safira

# Pencanangan SE2026

Materi informasi dari pusat : https://drive.google.com/file/d/1vptnMBHcI2DfGxYfY_ST_CVg096_UyOt/view?usp=sharing

1. Kertas pencanangan ukuran A3 glosi. ttd wabub dan pak nawer
2. Video transisi untuk sambutan
3. Video dan audio effect pada saat pengalungan id card
4. Rundown dan penjelasan teknis pencanangan

IT dan visual audio

- Butuh kabel untuk menghubungkan laptop operator terkait video audio dan bahan paparan
- Selalu berkoordinasi dengan tim perkap bupati

# Publisitas Dukunagan Lapangan

1. Perkuat kapasitas petugas mengenai konsep dan definisi dengan remainder kodef secara rutin
    1. PJ : Safira
    2. Yang perlu disiapkan
        1. Jadwal upload di feed IG dan share ke grup PPL dan PML
        2. Topik yang akan dishare
        3. Desain menggunakan gemini ai humas. buat 1 percakapan khusus untuk membuat desain itu agar desainnya konsisten
2. Perkuat kapasitas petugas mengenai pengetahuan umum SE2026 untuk menepis berita bohong dan tidak benar yang tersebar luas di internet
3. Bantu petugas untuk membangun citra positif dengan upload dan share video dukungan tokoh publik
    1. Ajak kolaborasi dari dinas kominfo dan humas dinas terkait. kalo perlu
    2. PJ :Sukma dan Vaniya
    3. Sukma : Edit video
    4. Vaniya : Buat thumbnail dan caption

![image.png](Publisitas%20dan%20Humas%20SE2026/image.png)

1. Motivasi petugas melalui feed instagram yang di upload dan dishare di grup petugas
2. After movie SE2026
    1. Konsepnya kyak video cinematic
    2. Pesan yang ingin disampaikan adalah : Kunci dari kebijakan yang tepat sasaran adalah data. Data yang berkualitas dikumpulkan dengan serangkaian tahapan, usaha, dan dedikasi.
    3. Rancangan konsep awal : [https://chatgpt.com/share/6a40bd4d-e72c-83ec-9ab4-cc7344eacbea](https://chatgpt.com/share/6a40bd4d-e72c-83ec-9ab4-cc7344eacbea)