# Manajemen dan Strategi Sakernas

Last Edited Time: August 25, 2026 5:30 PM
Activity: Sakernas
Created By: Ahmad Aulia

# Sakernas Februari 2026

## Rencana Umum

- Mmebuat catatan pribadi mengenai rencana aksi mulai dari pelatihan, pelaksanaan lapangan, dan monitoring
- Mengkomunikasikan rencana aksi melalui briefing tim sosial
- Membagi tugas sesuai rencana aksi dengan to do list agar efieisn pengerjaan tugas dan tidak duplikasi pekerjaan
- Mengkomunikasikan lewat grup agar informasi dapat diketahui semua anggota tim
- Perlu membuat list bukti dukung untuk sakip dan qgate agar proses pengumpulan bukti dukung efisien
- Perlu membuat direktori yang terintegrasi dalam menyimpan bukti dukung

## Pelatihan Online

### Perlu Disampaikan Ke Petugas

- Abdul Adzis suruh konfirmasi penawaran kerja di akun sobat, kalo ga punya aplikasinya kasih web nya
- Diakhir pertemuan ingatkan petugas untuk mengisi absensi PJJ
- Minta untuk mengisi form biodata
- Follow up dan kejar praktik fasih mobile terutama punya abdul adzis

## Rencana Pelatihan Petugas Offline

### Kegiatan Pelatihan offline secara umum

1. **Strategi pelatihan**
    1. Persiapan sebelum pelatihan
        1. Hubungi semua petugas H-1 pelatihan, berikan remainder
    2. Outline pelatihan offiline
        1. Pengenalan mengenai survey
        2. Strategi dan timeline
        3. Cara memulai wawancara (ditujukan untuk petugas baru)
        4. Cara menggunakan fasih dan aplikasi monitoring
    3. Pada saat materi modul 1 -2 langsung gunakan praktek pada fasih agar petugas lebih familiar dangan Fasih
    4. Pada saat pelatihan offline split waktu dengan teori dan banyak praktek
    5. Ajari cara penggunaan Fasih dengan aplikasi monitoring appsheet diawal bersamaan dengan strategi Pendataan
2. **Praktek penggunaan aplikasi Fasih Mobile**
    1. Perlu penggunaan fasih mobile pada nox
    2. Penggunaan akun PML untuk demo penggunaan fasih
    3. Tips and trik dalam penggunaan fasih agar tidak bermasalah
    4. Eksplore fitur Fasih
3. **Role playing**
    1. Perlu konfirmasi apakah jadi role playing di hari 1 pelatihan offline
    2. Langsung menggunakan fasih dalam role playing
    3. Pembagian kelompok sesuai banyak responden role playing
        1. 1 kelompok ada PML dan PPL yang terdistribusi merata berdasarkan nilai akademik
4. **Review materi secara keseluruhan**
    1. Materi dibagi menjadi 2 :
        1. Modul 1-19
        2. Modul 20-24
    2. Banyak diskusi
        1. Tanya jawab
        2. Contoh kasus untuk pengisian pertanyaan tertentu
    3. Daftar nama menurut nilai akademik akhir, yg nilainya paling kecil sering diajak diskusi untuk meningkatkan nilai keaktifan
    4. Bahan ajar untuk menunjang diskusi dan penegasan materi

## Teknis Lapangan

### File Kelengkapan Pelatihan PPL dan PML dari Provinsi

[https://drive.google.com/drive/folders/13er4JswLzcIiPmxiI29Xzlj-uVQ4JKz_?usp=drive_link](https://drive.google.com/drive/folders/13er4JswLzcIiPmxiI29Xzlj-uVQ4JKz_?usp=drive_link)

### Evaluasi Lapangan

- Perlu adanya penjelasan singkat mengenai metode pemilihan sampel pada petugas untuk berjaga-jaga ada pertanyaan mengenai alasan pemilihan sampel
- Perlu penjelasan mengenai mekanisme kuesioner yang dapat memvalidasi jawaban sehingga mengantisipasi jawaban yang tidak wajar
- Banyak responden yang mengira pendataan untuk bansos dan kalo dijelaskan bah ini bukan untuk bansos tetep ngeyel
- Responden jawabnya tidak jujur

# Sakernas Mei 2026

## Rapat Persiapan Nasional

- Anggaran belum ada
- tidak ada pelatihan tapi ada briefing

## Strategi Manajemen

- translok mitra 1 SLS 1 OK. Kecuali pak Handoko tambanh 1 OK karena daerah sulit. Sisa anggaran translok mitra revisi untuk pengawasan PML
- Konsumsi briefing 17k snack dan 51k makan untuk 10 peserta
- Briefing dilaksanakan jam 08.00-15.00 WIB menggunakan baju batik

### Keuangan

**Translok Mitra**

Jumlah PPL = 6

Jumlah PML = 2

| **Detil** | **Pagu** | **Anggaran Digunakan** | **OK - SLS dan Wilayah Sulit** | **Sisa untuk revisi** |
| --- | --- | --- | --- | --- |
| Translok Updating | Rp1,870,000 | Rp1,300,000 | 13 | Rp570,000 |
| Translok Pendataan | Rp1,870,000 | Rp1,300,000 | 13 | Rp570,000 |

### Link Postest

[https://forms.gle/d3mjRc1BB3ptdyZh7](https://forms.gle/d3mjRc1BB3ptdyZh7)

### Link Pretest

[https://forms.gle/Log3wYTi1mgDe2Ss9](https://forms.gle/Log3wYTi1mgDe2Ss9)

# Sakernas Agustus 2026

## Pelatihan Petugas

Bahan Teknis Pelatihan Petugas Sakernas Agustus : https://onedrive.live.com/?redeem=aHR0cHM6Ly8xZHJ2Lm1zL2YvYy8yMGE2ZTEwZmM5ZDdlNmRhL0lnQ1FjZVNKWDRXM1JhSHpHQWE1WkhmdUFlbjZoMW1nZ21WUDJwanhxSmItOGlVP2U9ZkRUVVZX&id=20A6E10FC9D7E6DA%21s89e47190855f45b7a1f31806b96477ee&cid=20A6E10FC9D7E6DA

- Jelaskan dulu gambaran sakernas itu bagaimana mulai dari pemutakhiran, izin ke desa, izin ke RT sampai pendataan.
- Tekankan dulu konsep alur proses bisnisnya, lupakan sejenak media pendataannya
- Pada saat pelatihan online, tekanakan mereka paham alur proses bisnis dan alur kuesioner
- Pada saat pelatihan offline, tekankan mereka paham cara memakai fasih, cara wawancara, dan banyakin review materi
- Mungkin pada saat pelatihan online, buat penjelasan secara bahasa orang awam dan bahasa lapangan, jangan terlalu tekstual.
- Buat soal latihan lebih ke studi kasus
- Tegaskan konsep dasar dalam pemutakhiran seperti definisi keluarga dan rumah tangga
- Buat agar petugas lebih cepat familiar dan beradaptasi dengan fasih
- Penjelasan pilah-pilah materi yang sangat penting. materi yang sudah jelas seperti pendidikan disabilitas dll kyak gitu ga usah dijelaskan terlalu banyak
- Lakukan briefing mandiri dalam 1 tim PML dengan para mitra
- Pada saat pelatihan offline buat waktu pemakaian fasih dan diskusi antar tim lebih banyak waktu. alokasikan waktu sejak jam 1 siang sampai jam 4 sore
- Pada saat pelatihan offline jelaskan strategi lapangan dan administrasi. Siapkan bahan paparannya dan aplikasi laporan perjalanananya
- Pada waktu pelatihan offline kasih tau kalo pada saat setelah pendataan catatan jangan dibuang dulu, tetap disimpan karena masih ada tahap evaluasi anomali dan validasi data

## Strategi Pemutakhiran

- Untuk konfirmasi batas SLS perlu koordinasi dengan petugas SE yang bertugas pada SLS tersebut
    - Identifikasi SLS nya udah dilisting apa belum
    - Nanti PPL sakernas turun bareng PPL SE
    - Kalo susah, minta pendampingan sama tokoh masyarakat setempat
    - Buat narasi kalo ini adalah lanjutan dari sensus, hanya orang
- Buat list mana SLS yang masuk sebagai SLS Sampel Februari dan Mei. pastikan peta SLS nya masih ada dan konfirmasi ke petugas sebelumnya kalo di RT itu ada perubahan batas atau tidak. kalo ada perubahan batas, tetap ikuti cakupan pemutakhiran februari dan mei
- Sampaikan kalo ini adalah Survei, kelanjutan dari sensus
- Patikan semua yang di upadate pada prelist orangnya memang ada ditempat, jangan sampek memutakhirkan hanya tanya RT saja tanpa ngecek langsung ke rumah nya apakah dia ada di tempat atau tidak
- Untuk penambahan keluarga baru pastikan nama KK tidak terdapat pada prelist
- Untuk Keluarga baru tidak pasti akan menjadi rumah tangga baru, bisa jadi dalam 1 rumah ada keluarga tambahan
- Perlu memahami fasih

PPL Sakernas mengisi isian prelist awal dari isian SE
PPL Sakernas mengurutkan no bangunan sesuai no bangunan konsep sakernas
Biar mengurutkannya mudah minta konfirmasi lokasi rumah dan pemiliknya ke pak RT sambil di beri no pada peta
Terus buat daftar nama KK di kertas
Begitu keliling untuk menanyakan pengelolaan makan minum sambil mengurutkan nomor bangunan tinggal konfirmasi aja orang nya masih tinggal disini atau tidak
Bilang ke pak RT nya kalo akan ada survey untuk mengecek program kerja tentang tenaga kerja, yg disurvey cuma 10 rumah, tapi kita mau ngecek dulu, orang nya masih tinggal disini atau tidak
Lakukan pendekatan ke pak RT kalo ada responden yg sulit minta tolong ditemani

## Permasalahan Lapangan

| **Masalah** | **Rencana Penyelesaian** |
| --- | --- |
| **Nurmala** susah dihubungi dan progres kerjanya lambat |   • Tetap jaga agar submit selesai di waktu aman
  • Uji coba untuk reject beberapa assigment, jika perbaikannya susah langsung tembak aja ke petugas sensus, tanya karakteristik pekerjaan dan betulkan sendiri isian sakernasnya |
| **Bang Agus dan Bang Latif** terlalu sibuk dan tidak ada waktu untuk mengerjakan sakernas. Responden susah ditemui karena sedang ada acara maulid |   • Tetap jaga agar bisa selesai submit tgl 26 sore, kalo ga bisa langsung tembak keterangan dari ketua RT, dan langsung submit, baru nanti untuk perbaikannya pakai hasil reject. Pastikan approve PML semua tgl 30 Agustus |
| **Fanny Amaranda** ada 1 responden yang sudah ditemui. Harusnya dia tidak ditemukan tapi malah ditemukan dan jadi sampel. Pada SE juga tidak ditemukan. Masih ada 6 assigment yg belum disubmit per tgl 25 Agustus |   • Suruh submit semua assigment kecuali ishak pada tgl 25 Agustus.
  • Untuk yg Ishak perlu diwawancara melalui telepon atau diwawancara di tempat dia bekerja
  • Untuk assigment yg lain perlu di konfirmasi semua dengan petugas SE |
| **Luthfi Ramadhan** ada 1 responden yang susah ditemui |   • Perlu konfirmasi isian dengan SE untuk ngecek kualitas isiannya |
| **Sulastri** ada 1 responden yang pindah ke kapuas hulu dan di SE tidak ditemukan. harusnya memang di pemutakhiran sakernas juga tidak ditemukan |   • Ambil datanya dari regsosek. Kalo di SE sumber prelisnya dari ST sama UMKM, jadi coba cek raw data dari ST dan UMKM |