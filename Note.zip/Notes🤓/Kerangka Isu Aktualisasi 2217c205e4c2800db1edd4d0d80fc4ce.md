# Kerangka Isu Aktualisasi

Last Edited Time: July 4, 2025 12:49 PM
Activity: Latsar
Created By: Ahmad Aulia

# Calon Isu

1. **Belum terlaksananya monitoring From Rencana Aksi (FRA) Triwulanan secara rutin**
    
    Monitoring Form Rencana Aksi (FRA) adalah kegiatan untuk memantau dan mengevaluasi capaian program yang telah dilaksanakan selama tiga bulan terakhir. Hasil evaluasi ini digunakan untuk mengidentifikasi permasalahan yang muncul dan merumuskan rencana kerja untuk tiga bulan berikutnya agar lebih tepat sasaran. Jika monitoring FRA tidak dilakukan secara rutin, maka capaian program tidak dapat diketahui secara objektif, evaluasi tidak terlaksana, dan kesalahan yang sama berpotensi terulang setiap triwulan. Akibatnya, perencanaan program ke depan menjadi kurang akurat karena tidak didasarkan pada data dan hasil evaluasi periode sebelumnya.
    
2. **Pembuatan dokumen Surat Pertanggungjawaban yang tidak efisien**
    
    Pembuatan dokumen Surat Pertanggungjawaban (SPJ) merupakan kewajiban untuk pencairan dana kegiatan sekaligus bentuk akuntabilitas penggunaan sumber daya negara. Selain tugas teknis, tim kerja juga harus menyelesaikan pekerjaan administratif seperti penyusunan dokumen pendukung pencairan honor petugas, transport lokal petugas, transport lokal pemeriksaan lapangan dan supervisi. Namun, proses administratif yang masih manual dan data yang tersebar membuat pengerjaannya memakan waktu cukup banyak. Akibatnya, waktu untuk menyelesaikan pekerjaan teknis menjadi berkurang, sehingga output kegiatan sering kali tidak maksimal atau tidak mencapai target.
    
3. **Koordinasi penawaran mitra setiap bulan belum optimal**
    
    Penawaran kerja kepada mitra statistik di BPS dilakukan setiap bulan untuk mendukung pelaksanaan berbagai kegiatan survei. Berdasarkan Peraturan Kepala BPS Nomor 115 Tahun 2024, setiap mitra memiliki batas maksimal honor yang dapat diterima dalam satu bulan. Oleh karena itu, diperlukan koordinasi antar tim kerja agar penugasan kepada mitra tidak melebihi batas tersebut. Namun, dalam praktiknya masih ditemukan kasus mitra menerima honor melebihi ketentuan, yang mengakibatkan keterlambatan administrasi pembayaran dan berdampak pada realisasi penyerapan anggaran yang tidak memenuhi target.
    
    Sumber : 
    
    [https://blog.minitab.com/en/four-types-of-fishbone-diagrams?utm_source=chatgpt.com](https://blog.minitab.com/en/four-types-of-fishbone-diagrams?utm_source=chatgpt.com)
    
    [https://creately.com/guides/types-of-fishbone-diagram/?utm_source=chatgpt.com](https://creately.com/guides/types-of-fishbone-diagram/?utm_source=chatgpt.com)