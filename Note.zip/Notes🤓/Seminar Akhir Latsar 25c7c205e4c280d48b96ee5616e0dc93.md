# Seminar Akhir Latsar

Last Edited Time: August 28, 2025 10:25 AM
Activity: Latsar
Created By: Ahmad Aulia

Semangat pagi teman-teman peserta,
Menginfokan beberapa hal terkait Seminar Pelatihan Dasar CPNS sebagai berikut:

1. ID ZOOM peserta dan mentor (online) saat seminar: [angkatan].[kelompok].[nama lengkap];
2. Mekanisme seminar akan dilakukan secara Breakout Room (BO);
3. Siswa dan Mentor secara mandiri masuk ke dalam ruang BO secara mandiri;
4. Hadir 10 menit sebelum jadwalnya di dekat ruang seminar dan di main room zoom sebelum urutan peserta sebelumnya berakhir;
5. Menyiapkan semua bahan seminar sebelum memasuki ruang seminar;
6. Mentor mengisi penilaian peserta dan presensi seminar pada tautan [https://s.bps.go.id/InfoLatsar25](https://s.bps.go.id/InfoLatsar25) ;
7. Peserta wajib melengkapi data lengkap mentor pada GOJAGS;
8. Mentor dan seluruh peserta wajib masuk ke ruang zoom saat melakukan seminar pada tautan [https://s.bps.go.id/InfoLatsar25](https://s.bps.go.id/InfoLatsar25) ;
9. Peserta menggunakan pakaian diklat hitam putih dan mentor menggunakan batik;
10. Mengkomunikasikan kepada penyelenggara/APM, apabila terdapat perubahan urutan atau terkendala saat seminar.

https://www.canva.com/presentation/control?id2=8043427b-22ed-43e2-81b5-0607c12c2869&extension=LuXyHaEG4YgkmE0r6PB6nQ

**Pembuka**

Pergi ke pasar membeli terasi,

Pulangnya bawa sayur bayam ditangan kiri.

Sebelum memulai presentasi,

Mohon izin untuk memperkenalkan diri.

**Penutup**

Bunga mawar tumbuh di taman,

Hijau dan harum bau pandan.

Terima kasih dan mohon maaf atas segala kesalahan,

Sampai jumpa di lain kesempatan

- typo
- membuat fitur saran fqa
- pembatasan akses