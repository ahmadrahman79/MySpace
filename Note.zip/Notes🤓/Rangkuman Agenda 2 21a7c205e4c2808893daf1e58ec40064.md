# Rangkuman Agenda 2

Last Edited Time: June 28, 2025 11:37 AM
Activity: Latsar
Created By: Ahmad Aulia

# Rangkuman 1

## 🌟 **Konsep Utama: Berorientasi Pelayanan**

### 📌 Pengertian

Berorientasi pelayanan berarti:

> “Komitmen ASN untuk memberikan pelayanan terbaik, cepat, ramah, tepat, dan terus diperbaiki, demi kepuasan masyarakat.”
> 

Pelayanan publik bukan sekadar tugas administratif, tapi **wujud nyata dari kehadiran negara** dalam memenuhi hak warganya.

---

## 🧭 **Teori & Regulasi Pendukung**

### 1. **Undang-Undang Nomor 25 Tahun 2009**

Tentang Pelayanan Publik:

- Pelayanan adalah hak warga, kewajiban negara.
- Menuntut adanya kepastian, kecepatan, keterjangkauan, dan keadilan.

### 2. **UU ASN No. 5 Tahun 2014**

- ASN = Pelaksana kebijakan publik + Pelayan publik + Perekat bangsa.

### 3. **Core Values ASN – BERAKHLAK (SE MenPANRB No. 20/2021)**

- Nilai pertama: **Berorientasi Pelayanan**
- Diperkuat dengan slogan “Bangga Melayani Bangsa”

---

## ✅ **3 Panduan Perilaku Utama**

### 1. **Memahami & Memenuhi Kebutuhan Masyarakat**

- ASN wajib paham kebutuhan masyarakat, bukan sekadar prosedur.
- ASN bukan “penguasa layanan”, tapi pelayan masyarakat.

🔍 **Contoh di BPS Kabupaten/Kota:**

> Seorang staf statistik menyusun jadwal pendataan SUPAS dengan menyesuaikan waktu panen warga desa agar tidak mengganggu aktivitas mereka. Juga, menyediakan informasi hasil statistik dengan bahasa sederhana di balai desa.
> 

---

### 2. **Ramah, Cekatan, Solutif, dan Dapat Diandalkan**

- Layanan yang diberikan harus:
    - Senyum, salam, sapa
    - Cepat dan tepat waktu
    - Memberikan solusi, bukan menambah masalah

🔍 **Contoh di BPS Kabupaten/Kota:**

> Operator front office merespons cepat permintaan data dari dinas pendidikan dengan mengarahkan ke kanal unduh resmi dan membantu membaca metadata file yang diminta.
> 

---

### 3. **Melakukan Perbaikan Tiada Henti**

- Pelayanan selalu bisa ditingkatkan.
- ASN harus proaktif berinovasi meski kecil skalanya.

🔍 **Contoh di BPS Kabupaten/Kota:**

> Seorang koordinator tim pemutakhiran wilayah kerja SUPAS mengusulkan form digital sederhana di Google Form untuk pelaporan harian petugas, agar cepat direkap dan efisien dibanding kertas.
> 

---

## 🚧 Tantangan Implementasi

- **Eksternal:** kondisi geografis sulit, budaya lokal tertutup, keterbatasan akses internet.
- **Internal:** SDM terbatas, birokrasi yang lambat, budaya pelayanan belum kuat.

💡 Namun, tantangan ini **peluang untuk berinovasi.** Bahkan meniru inovasi dari daerah lain adalah sah dan dianjurkan jika sesuai konteks lokal.

---

## 🔁 Penutup: Kenapa Ini Penting?

Berorientasi pelayanan bukan hanya nilai, tapi cerminan **jati diri ASN.** Pelayanan yang baik menciptakan kepercayaan publik, memperkuat legitimasi negara, dan mempercepat pencapaian pembangunan, termasuk SDGs.

📍Di BPS, pelayanan bukan cuma soal data, tapi juga soal **bagaimana data itu hadir tepat waktu, dapat dipahami, dan bermanfaat untuk masyarakat.**

## 2. ✅ **Akuntabel**

### 📌 Konsep

Akuntabel berarti bisa **dipercaya dan dapat mempertanggungjawabkan** setiap tindakan dan penggunaan sumber daya publik.

### 🧭 Regulasi

- **UU No. 28/1999** tentang penyelenggaraan negara yang bersih dan bebas KKN
- **UU ASN No. 5/2014** menekankan ASN wajib bertindak profesional, bertanggung jawab, dan berintegritas.

### 🧠 Perilaku Akuntabel:

1. Jujur, cermat, disiplin, dan bertanggung jawab.
2. Menggunakan barang milik negara secara efisien.
3. Tidak menyalahgunakan kewenangan.

🔍 **Contoh di BPS:**

> Petugas pengelola anggaran kegiatan Sensus memastikan seluruh kuitansi, SPPD, dan bukti perjalanan lengkap dan sesuai ketentuan agar laporan bisa dipertanggungjawabkan saat audit.
> 

---

## 3. 📚 **Kompeten**

### 📌 Konsep

Kompeten artinya **terus belajar dan mengembangkan diri**, serta mampu menyelesaikan tugas dengan kualitas terbaik.

### 🧭 Teori

- **VUCA & Disrupsi Teknologi** jadi tantangan: ASN harus agile dan belajar cepat.
- ASN harus memenuhi standar **SMART ASN**: melayani, akuntabel, kompeten, harmonis, loyal, adaptif, kolaboratif.

### 🧠 Perilaku:

1. Meningkatkan kemampuan diri.
2. Membantu orang lain belajar.
3. Memberikan hasil kerja terbaik.

🔍 **Contoh di BPS:**

> Seorang staf bidang produksi statistik aktif ikut pelatihan data science lalu membagikan ilmunya dalam forum internal untuk peningkatan kualitas analisis indikator statistik daerah.
> 

---

## 4. 🤝 **Harmonis**

### 📌 Konsep

Harmonis berarti menjaga **hubungan baik dan menghargai keberagaman**, serta menciptakan lingkungan kerja yang nyaman.

### 🧭 Regulasi & Etika

- Sesuai etika publik ASN: menghormati semua latar belakang & menjaga sikap inklusif.

### 🧠 Perilaku:

1. Menghargai perbedaan (suku, agama, pendapat).
2. Saling bantu dan tolong-menolong.
3. Menciptakan suasana kerja yang nyaman.

🔍 **Contoh di BPS:**

> Di tengah tim lintas lintang agama dan suku, koordinator kegiatan Supas mengajak semua anggota membuat forum santai mingguan untuk membangun keakraban dan semangat gotong royong dalam pendataan lapangan.
> 

---

## 5. 🇮🇩 **Loyal**

### 📌 Konsep

Loyal berarti setia pada **Pancasila, UUD 1945, NKRI**, dan pimpinan, serta menjaga nama baik instansi dan negara.

### 🧭 Regulasi

- SE MenPANRB No. 20/2021
- UU ASN No. 5/2014 pasal 10

### 🧠 Perilaku:

1. Setia kepada negara & pemerintahan yang sah.
2. Menjaga rahasia jabatan.
3. Menjaga citra dan integritas ASN.

🔍 **Contoh di BPS:**

> Seorang pegawai BPS tetap menjaga netralitas dan tidak menyebarkan hoaks atau opini politik di media sosial meski sedang tahun pemilu, sebagai wujud loyalitas kepada instansi dan negara.
> 

---

## 6. 🔄 **Adaptif**

### 📌 Konsep

Adaptif berarti mampu **cepat beradaptasi dengan perubahan**, berpikir kreatif, dan proaktif menghadapi tantangan baru.

### 🧭 Teori

- ASN perlu adaptif di era digital, teknologi cepat berubah.
- Diperlukan organisasi yang tangguh dan agile.

### 🧠 Perilaku:

1. Cepat beradaptasi.
2. Berinovasi dan kreatif.
3. Proaktif dalam menyelesaikan masalah.

🔍 **Contoh di BPS:**

> Ketika aplikasi entry data SUPAS offline, seorang pegawai langsung membuat solusi pengisian sementara dengan Google Form agar pelaporan petugas tidak tertunda.
> 

---

## 7. 🤝 **Kolaboratif**

### 📌 Konsep

Kolaboratif artinya mau bekerja sama lintas sektor, **terbuka dengan ide pihak lain**, dan menggunakan sumber daya bersama.

### 🧭 Teori

- ASN tidak bisa kerja sendiri—perlu sinergi antar instansi, sektor swasta, dan masyarakat.

### 🧠 Perilaku:

1. Memberi ruang kontribusi pihak lain.
2. Terbuka dalam kerja tim.
3. Memanfaatkan sumber daya bersama.

🔍 **Contoh di BPS:**

> BPS menggandeng dinas kependudukan untuk menyinkronkan data SUPAS dengan data administrasi desa demi validitas, serta mengundang tokoh masyarakat untuk mendukung kegiatan pendataan di lapangan.
> 

# Rangkuman 2

## 🧭 PENDAHULUAN

**BerAKHLAK** adalah nilai dasar ASN yang ditetapkan melalui Surat Edaran Menteri PANRB No. 20 Tahun 2021, dan merupakan turunan dari UU ASN No. 5 Tahun 2014 pasal 5.

Tujuannya adalah untuk menciptakan ASN yang profesional, berintegritas, dan melayani dengan semangat “**Bangga Melayani Bangsa**”.

---

## 🌟 1. BERORIENTASI PELAYANAN

### ✅ Definisi:

Memberikan pelayanan prima kepada masyarakat secara cepat, tepat, ramah, dan solutif.

### 🧭 Panduan Perilaku:

- Memahami dan memenuhi kebutuhan masyarakat
- Ramah, cekatan, solutif, dan dapat diandalkan
- Melakukan perbaikan tiada henti

### 📌 Implementasi di BPS Kab/Kota:

- Petugas pelayanan data membantu OPD mencari data sektoral yang relevan dan menjelaskan sumber datanya dengan bahasa yang mudah dipahami.
- ASN menyediakan layanan statistik digital seperti dashboard publikasi online untuk meningkatkan kemudahan akses masyarakat.

---

## 📊 2. AKUNTABEL

### ✅ Definisi:

Bertanggung jawab atas setiap keputusan dan tindakan, transparan dalam proses kerja, serta taat pada aturan dan etika profesi.

### 🧭 Panduan Perilaku:

- Melaksanakan tugas dengan jujur, cermat, dan berintegritas
- Efisien dan bertanggung jawab dalam menggunakan aset negara

### 📌 Implementasi di BPS Kab/Kota:

- Menginput laporan kegiatan survei secara tepat waktu dalam sistem BOS atau SIDATAS.
- Menyampaikan laporan realisasi anggaran kegiatan sesuai kondisi di lapangan, bukan manipulatif.

---

## 🧠 3. KOMPETEN

### ✅ Definisi:

Terus belajar dan mengembangkan diri untuk menghadapi tantangan dan memenuhi kebutuhan zaman.

### 🧭 Panduan Perilaku:

- Meningkatkan kompetensi diri
- Membantu orang lain belajar
- Melaksanakan tugas dengan kualitas terbaik

### 📌 Implementasi di BPS Kab/Kota:

- ASN mengikuti pelatihan pengolahan data statistik, GIS, atau dashboard interaktif secara mandiri maupun institusional.
- Membuat dokumentasi teknis dari pekerjaan yang bisa dibaca pegawai baru atau mitra.

---

## 🤝 4. HARMONIS

### ✅ Definisi:

Membangun lingkungan kerja yang saling menghargai dan mendukung.

### 🧭 Panduan Perilaku:

- Menghargai perbedaan latar belakang
- Mendorong dan mendukung sesama rekan
- Membangun lingkungan kerja yang kondusif

### 📌 Implementasi di BPS Kab/Kota:

- Saat terjadi konflik jadwal survei antar tim, pegawai mencari jalan tengah yang adil bersama-sama, tanpa menyalahkan.
- Mendukung mitra statistik baru dengan bimbingan langsung selama pelatihan lapangan.

---

## 🛡️ 5. LOYAL

### ✅ Definisi:

Setia kepada bangsa, negara, dan pemerintah yang sah, serta menjaga kehormatan instansi.

### 🧭 Panduan Perilaku:

- Memegang teguh ideologi Pancasila dan UUD 1945
- Menjaga nama baik sesama ASN dan instansi
- Menjaga rahasia jabatan dan negara

### 📌 Implementasi di BPS Kab/Kota:

- ASN tidak terlibat politik praktis dalam media sosial dan kehidupan kerja.
- Menjaga kerahasiaan data sensus atau survei strategis seperti angka kemiskinan sebelum dirilis.

---

## 🔄 6. ADAPTIF

### ✅ Definisi:

Cepat beradaptasi dengan perubahan dan aktif melakukan inovasi untuk memperbaiki kinerja.

### 🧭 Panduan Perilaku:

- Cepat menyesuaikan diri dengan perubahan
- Terus berinovasi dan kreatif
- Proaktif menanggapi tantangan

### 📌 Implementasi di BPS Kab/Kota:

- ASN tetap melaksanakan pengolahan data di rumah (WFH) dengan membuat sistem koordinasi lewat Google Meet/Zoom saat pandemi.
- Membuat inovasi spreadsheet monitoring capaian survei real-time di tingkat kabupaten.

---

## 🤝 7. KOLABORATIF

### ✅ Definisi:

Membangun sinergi dengan semua pihak demi hasil kerja yang optimal.

### 🧭 Panduan Perilaku:

- Memberi ruang kontribusi kepada berbagai pihak
- Terbuka bekerja sama untuk hasil terbaik
- Memanfaatkan sumber daya bersama untuk tujuan bersama

### 📌 Implementasi di BPS Kab/Kota:

- Berkoordinasi dengan Dinas Sosial dalam validasi data kemiskinan lokal.
- Kolaborasi dengan Kominfo untuk publikasi data tematik melalui media sosial resmi kabupaten.

---

## 🎯 KESIMPULAN

Nilai-nilai **BerAKHLAK** bukan hanya pedoman, tapi *identitas budaya kerja ASN*. Dengan menerapkannya:

- ASN menjadi profesional, melayani, dan berintegritas
- Layanan publik menjadi cepat, ramah, dan akurat
- Birokrasi menjadi modern dan dipercaya publik

> Di BPS, penerapan BerAKHLAK akan menghasilkan ASN yang tidak hanya unggul dalam data, tapi juga unggul dalam etika, komunikasi, dan pelayanan.
>