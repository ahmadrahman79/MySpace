# Podes

Last Edited Time: April 9, 2026 2:58 PM
Activity: Podes
Created By: Ahmad Aulia

# **Podes 2026**

## Timeline :

- Pendataan : 15 April - 5 Mei 2026
- Pemeriksaan PML : 20 Mei 2026
- Approval Admin Fasih SM : 5 Juni 2026 (Sesuai Jadwal Pusat, *tapi kalo bisa sudah selesai sebelum tgl ini untuk antisipasi masalah sistem dan kerjaan tidak terduga*)

## Administrasi

- Translok PML (*RPD Juni*) :
    - pra pendataan = 1 OK per PML
    - Pendataan = 3 OK per PML
- Translok PPL (*RPD Juni*) :
    - pra pendataan  = 1 OK per PPL
    - Pendataan = 2 OK per PPL
- Honor Petugas (*RPD Mei*)