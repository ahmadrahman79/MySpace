# Catatan Rapat Eval GC PBI Tahap 2

Last Edited Time: April 21, 2026 8:41 PM
Activity: GC PBI
Created By: Ahmad Aulia

### Pertanyaan Pending

- Bagaimana kalo ART pindah ke luar wilayah cuma tau pulau nya aja, tapi ga tau di provinsi mana atau kota mana?

### Permasalahan Hasil Diskusi

- Galat untuk hubungan dengan kepala keluarga
- Bagaiamana metode perhitungan desil yang secara sederhana, standar nya gimana

### Pertanyaan

- NIK tidak terbaca, jadi gimana. karena yg jadi target adalah anaknya tapi orangtua nya ga bisa ditambahkan
- Ada keluarga yang tidak ditemukan karena pindah
- Ada anggota keluarga yang pecah KK
- Bagaimana cara perhitungan luas lantai yg dalam rumah yang lebih dari 2 keluarga