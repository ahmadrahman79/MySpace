# DTSEN

Last Edited Time: April 21, 2026 8:41 PM
Activity: DTSEN
Created By: Ahmad Aulia

# Metode PMT (Penentuan Desil DTSEN)

Sejauh ini yang dipahami…

### Penjelasan secara teoritis dan lanjutan

Penentuan desil menggunakan metode PMT Regsosek yang dimodifikasi dan divalidasi dengan data PLN, BPJS Kesehatan. Sebelum dihitung desilnya, raw data dipadankan dengan memvalidasi data dukcapil.

### Penjelasan dengan bahasa bayi

Perhitungan desil mempertimbangkan aspe aset, perumahan, tingkat pendidikan dan pekerjaan, dan jumlah anggota keluarga. Aspek aset dan perumahan dikonversi kedalam nilai rupiah. dari semua variabel itu setelah dikonversi ke dalam nilai rupiah sesuai kondisi kelayakannya (apakah baik, rusak ringan, rusak sedang, atau rusak berat) kemudian dijumlahkan, sehingga didapatkan nilai kesejahteraan (didekati dengan estimasi pengeluaran yang dihitung dari PMT tadi). dari nilai rupiah yang digunakan sebagai pendekatan tingkat kesejahteraan  akan diurutkan dari yang paling kecil ke paling besar. nah kemudian dibagi rata ke 10 kelompok. jadi tidak ada nilai pasti cut off atau kriteria kondisi gimana masuk desil 1 kondisi gimana masuk desil 6. bisa jadi kalo nilai perumahannya rendah, tapi nilai aset nya tinggi. bisa jadi nilai perumahannya rendah, nilai pendapatannya rendah, tapi aset nya nilainya tinggi.