# Rencana Aksi Umum

Last Edited Time: April 21, 2026 8:49 PM
Activity: Strategi
Created By: Ahmad Aulia

Berdasar Evaluasi 2025

# Secara umum

- Perlu adanya pembiasaan PPL untuk mengisi appsheet laporan perjalanan
- Buat template perencanaan yang berisi rencana aksi untuk kegiatan yg aul jadi PJ nya, jadi kalo pas bertepatan dengan hal2 yg sibuk banget, template nya bisa di baca buat nge triger strategi yg bakal digunakan. Isinya mengenai apa saja yang perlu dibriefing kan dalam 1 tim, apa saja yang perlu disampaikan ke petugas
- Disetiap kegiatan yg PJ nya Aul, cek ulang to do list mana aja yg belum dilaksanakan untuk mempermudah kolaborasi, kalo yg PJ nya bukan aul, cek aja se sempatnya, tapi kalo bisa tetep di backup agar mempermudah kegiatan periode berikutnya dan kegiatan2 sosial lebih tertata dan ga semuanya di buat dari nol
- Buat perencanaan sekalian plan B jika ada meleset dari planning. dokumentasikan evaluasi setiap kegiatan secara pribadi. kemudian dijadikan bahan perbaikan perencanaan kegiatan periode berikutnya. Sempatkan waktu setelah bekerja untuk mengevaluasi proses kegiatan
- Buat list barang yang dibutuhkan untuk pelatihan, kemudian koordinasikan dengan tim gimana cara pengadaan barangnya, apakah kita pengadaan sendiri atau dari umum. kalo dari umum segera kirimkan list barang yg berisi :
    - Nama barang yang diperlukan
    - Anggaran yg tersedia di POK
    - Jumlah barang yang diperlukan
    - Tanggal pemakaian barang
- Perencanaan harus berbasis efisiensi cara kerja dan efektifitas
- Pembuatan insfrastruktur perlu dilakukan di awal
- Selalu lakukan briefing petugas PPL dan PML pada saat pelatihan. Hal yg wajib di briefing adalah :
    - Strategi kegiatan lapangan
    - Timeline
    - Cara penggunaan instrumen survei seperti appsheet
    - Administrasi apa saja yang perlu dikerjakan oleh petugas dan bagaimana cara pengerjaan administrasinya
    - Briefing penyelesaian anomali (Khusus PML)
- Perlu mempertahankan terlaksananya tertib matrik perjalanan dinas
- Perlu adanya transfer knowledge pada setiap orang yg akan off baik pindah tim atau cuti dengan anggota tim lainnya
- Menyampaikan informasi apa pun melalui grup agar semua anggota tim dapat mengetahui
- Untuk efisiensi dan efektifitas proses pencairan SPJ, buatkan dokumen SPJ yang sudah dapat disusun pada saat kegiatan dilakukan. Misalnya setelah pelatihan langsung buat dokumen SPJ nya dan buat catatan mana yang udah di buat mana yang belum. pada saat proses pendataan segera buat SPJ untuk honor dan tetap kan deadline pengumpulan Surat Tugas dan visum. Pastikan pesan surat tugas minimal H-2 agar terkejar ttd pak nawer, kalo nggak terkejar ttd pak nawer berarti turun lapangan tanpa surat tugas dulu, mungkin bisa cuma bawa visum aja. kemudian tetap kan kapan deadline pengumpulan surat tugas laporan dan visum.

## Rencana Aksi Kegiatan Rutin

## Administrasi

Siapkan aja dulu dokumen spj nya kalo POK atau KAK belum siap, bisa dilengkapi diakhir, yang penting dokumen pendukungnya sudah dibuat. Lihat apa aja yang perlu dicairkan di detil FA dan perhatikan RPD nya. kalo ada detil yang tidak perlu dicairkan, biarkan aja tetep gitu anggarannya. nanti diakhir tahun baru direvisi POK untuk dialihkan ke keperluan lain yang lebih produktif. **INGAT ITU UANG RAKYAT, JANGAN DISALAH GUNAKAN** 

- Tentukan semua detil pembebanan pencairan. catat, setelah itu baru eksekusi dokumen pendukung SPJ nya
- SPJ Translok Pelatihan
- SPJ Paket data
- SPJ Perlengkapan Petugas
- Dokumen administrasi (surat tugas dan visum)
- SPJ Translok petugas
- SPJ Translok perjadin PML
- SPJ Translok supervisi
- SPJ Honor

## Teknis

- Monitoring Lapangan
- Aplikasi monitoring lapangan
- Aplikasi pelaporan perjalanan
- Aplikasi/dokumen pendataan
- Google Site instrument pelatihan
- Google Site instrument kegiatan lapangan
- Bahan briefing strategi dan timeline