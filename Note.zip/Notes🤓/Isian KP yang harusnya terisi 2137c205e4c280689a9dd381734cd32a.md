# Isian KP yang harusnya terisi

Last Edited Time: June 15, 2025 9:26 AM
Activity: Susenas-Seruti
Created By: Ahmad Aulia

- harga sewa rumah
- pengeluaran listrik
- pertanyaan kendaraan bermotor
- bahan bakar memasak (LPG)
- biaya telekomunikasi
- sabun mandi
- perawatan kecantikan (kalo ada art perempuan)
- sabun cuci piring dan baju
- pengeluaran kesehatan dalam setahun
- biaya spp sekolah
- uang les
- uang komite
- pakaian
- pajak PBB
- pajak STNK