# Dokumen Pencairan

Last Edited Time: April 25, 2026 8:38 AM
Activity: Administrasi
Created By: Ahmad Aulia

## Honor Petugas (PPL/PML)

- BAST-SPK
- KAK
- Nominatif
- SK KPA
- FP

## Paket Data

- KAK
- Kuitansi pembelian paket data per Nomor tujuan
- FP

## Transport Pelatihan Petugas

- FP (PLTH)
- Nominatif (ada uang harian, translok sesuai SK translok per kecamatan, tempat berangkat sesuai kecamatan asal, tujuan = Mempawah) → kalo jenisnya PLTH
- Nominatif (isinya kyak nominatif perjalanan pendataan/updating listing) → kalo jenisnya TRANSLOK
- KAK
- DOP
- Kuitansi
- Daftar Hadir
- Surat tugas pelatihan (SPPD)
- Laporan Panitia
    - Jadwal kegiatan
    - Dokumentasi kegaitan

## Honor Inda/Innas

- Nominatif
- FP
- Surat tugas Inda/Innas
- KAK
- Laporan Inda

## Perjalanan Dinas Dalam Kota

- Nominatif
- FP
- Kuitansi-DOP
- KAK
- Surat Tugas
- SPPD dan Visum lampiran SPPD (Jika tidak absen)
- Visum (Jika Absen)
- Laporan Perjadin
- 

![image.png](Dokumen%20Pencairan/image.png)

## Perjalanan Pendataan Petugas

- Laporan
- Surat Tugas
- Visum
- Kuitansi-DOP
- KAK
- Nominatif
- FP