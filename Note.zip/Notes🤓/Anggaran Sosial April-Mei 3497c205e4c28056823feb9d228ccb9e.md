# Anggaran Sosial April-Mei

Last Edited Time: May 5, 2026 11:36 AM
Activity: Administrasi
Created By: Ahmad Aulia

- Sakernas Mei
- Podes
- Polkam
- Descan

## Revisi

- Perjalanan jumlah uang nya ga boleh bertambah tapi boleh berkurang
- Revisi anggaran ga boleh lintas kegiatan, misalnya podes ya hanya boleh direvisi di podes aja
- untuk perjadin ga boleh merubah total anggaran perjalanan dinas dalam 1 kegiatan misalnya podes, tapi boleh merubah jumlah OK atau OH nya
- RPD
    - RPD tanpa Podes : [https://docs.google.com/spreadsheets/d/1RzigLeuI6XbXNoVGa61kydjEa3GAIRs8/edit?usp=sharing&ouid=104939710040391820789&rtpof=true&sd=true](https://docs.google.com/spreadsheets/d/1RzigLeuI6XbXNoVGa61kydjEa3GAIRs8/edit?usp=sharing&ouid=104939710040391820789&rtpof=true&sd=true)
    - RPD podes :
    [https://docs.google.com/spreadsheets/d/1CB1RrAuOZEyCmv66vKcZh3fSa2_8W8lf/edit?usp=sharing&ouid=101283917117501899880&rtpof=true&sd=true](https://docs.google.com/spreadsheets/d/1CB1RrAuOZEyCmv66vKcZh3fSa2_8W8lf/edit?usp=sharing&ouid=101283917117501899880&rtpof=true&sd=true)

## Descan

- honorarium anggap sebagai cadangan konsumsi
- rapat evaluasi digunakan di akhir, jangan dipakai dulu

### Sakernas

- Lihat RPD di POK Excel ter baru, segera cairkan yg RPD nya minimal Maret- April
- Sisa anggaran ditabung dulu buat dipake di akhir tahun
    - Biarin aja segitu
    - jangan di tabung di ATK
- Jadi anngaran tuh kalo ga perlu ga usah dipaksakan saat itu. nanti di akhir dipakai
- Untuk supervisi SAK Feb pak nawer dibatalkan perjadinnya, karena bentrok sama perjadin SNLIK. jadi nanti minta pak adwin untuk TL
- Tanya ttd KAK yang ada pergantian PPK antara pembuatan KAK ttd bg arief dan KAK bg aller

### Susenas Seruti

- untuk honor PML Mitra susenas maret ada sisa karena memang ga kepake semua
- untuk detil honor seruti terintegrasi susenas itu detilnya jadi 1 antara maret sama september
- untuk detil honor seruti yg tidak terintegrasi susenas detilnya jadi 1 juga untuk tw 2 dan 4
- transport RH maret BELUM CAIR. semua orang 1 OH
    - Petugas :
        - bg pitra
        - pak yuyun
        - pak wandi
        - kak eca
        - bg aziz
        - bg yulfi
- pencairan transport supervisi susenas maret.
    - Pelaksana
        - mas pandi
        - pak nawer

### PODES

- ikuti RPD nya