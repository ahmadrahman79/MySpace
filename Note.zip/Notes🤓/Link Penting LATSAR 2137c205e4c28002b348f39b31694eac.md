# Link Penting LATSAR

Last Edited Time: June 15, 2025 9:22 AM
Activity: Latsar
Created By: Ahmad Aulia

## INFORMASI TERKAIT PEMBELAJARAN LATSAR

### Jadwal:

[https://docs.google.com/spreadsheets/d/1YbJ4x-64SV-jBINhznBU9Qb-tXI9tmX_/edit?gid=649026181#gid=649026181](https://docs.google.com/spreadsheets/d/1YbJ4x-64SV-jBINhznBU9Qb-tXI9tmX_/edit?gid=649026181#gid=649026181)

### File kelompok:

 [https://docs.google.com/spreadsheets/d/1Rn7-wNQVu9fOS-DU3DmNDoi0BFZeLlf7/edit?usp=sharing&ouid=117420667435523880709&rtpof=true&sd=true](https://docs.google.com/spreadsheets/d/1Rn7-wNQVu9fOS-DU3DmNDoi0BFZeLlf7/edit?usp=sharing&ouid=117420667435523880709&rtpof=true&sd=true)

### File deskjob pengurus kelas:

[https://docs.google.com/document/d/15WLbl2VmHGKCt4N_xTJuFySuP5LR9rdZ/edit?usp=sharing&ouid=117420667435523880709&rtpof=true&sd=true](https://docs.google.com/document/d/15WLbl2VmHGKCt4N_xTJuFySuP5LR9rdZ/edit?usp=sharing&ouid=117420667435523880709&rtpof=true&sd=true)

### File panduan breakout zoom dan penyiapan kelas:

[https://docs.google.com/presentation/d/1H0AGTC3OxXNRE7EYIdVg6ppKpYEIXJcr/edit?usp=sharing&ouid=117420667435523880709&rtpof=true&sd=true](https://docs.google.com/presentation/d/1H0AGTC3OxXNRE7EYIdVg6ppKpYEIXJcr/edit?usp=sharing&ouid=117420667435523880709&rtpof=true&sd=true)

### Link kolabjar:

[https://kolabjar-asnpintar.lan.go.id/](https://kolabjar-asnpintar.lan.go.id/)

### Pembekalan:

[https://docs.google.com/presentation/d/1yDP2oiLuD_wjQRLhSufAj6qmv6NBEpiD/edit?usp=drive_link&ouid=117420667435523880709&rtpof=true&sd=true](https://docs.google.com/presentation/d/1yDP2oiLuD_wjQRLhSufAj6qmv6NBEpiD/edit?usp=drive_link&ouid=117420667435523880709&rtpof=true&sd=true)

### Panduan PKTBT:

[https://drive.google.com/drive/folders/1FbDG7nz0Y3VZg6WmQEKfGRZ3E08sCplU?usp=drive_link](https://drive.google.com/drive/folders/1FbDG7nz0Y3VZg6WmQEKfGRZ3E08sCplU?usp=drive_link)