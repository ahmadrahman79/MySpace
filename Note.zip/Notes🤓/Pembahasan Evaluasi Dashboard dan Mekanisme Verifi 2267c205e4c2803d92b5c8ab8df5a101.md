# Pembahasan Evaluasi Dashboard dan Mekanisme Verifikasi Kematian Maternal

Last Edited Time: July 4, 2025 9:42 AM
Activity: Supas
Created By: Ahmad Aulia

- Hati dalam penulisan umur jangan sampek salah angka

## Mekanisme Verifikasi Kematian Maternal

- Indikator maternal dari SDKI sudah tidak dikumpulkan sebagai gantinya pakai supas dan sensus
- Indikator maternal digunakan untuk menilai kualitas layanan kesehatan ibu

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image.png)

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%201.png)

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%202.png)

- anggaran rapat dengan dinas kesehatan disediakan berupak traslok, jadi jika bps kab kota mengundang dinkes bisa pakai anggaran itu
- MPDN dikembangkan sejak 2021, harusnya sudah lengkap catatannya.
- Jika data kematian maternal supas tdk sesuai dengan MPDN, maka dilakukan verifikasi lapangan.
- untuk verifikasi lapangan boleh ngajak puskesmas, boleh sendirian, kalo ngajak puskkesmas, anggaran perjadin puskesmas dibebankan ke dipa puskesmas
- untuk pengecekan verifikasi kematian maternal ke lapangan menggunakan anggaran supervisi. anggaran supervisi untuk verifikasi kematian maternal dibuat global untuk supervisi
- BPS RI sudah bekerja sama dng kementrian kesehatan agar kementrian kesehatan memerintahkan puskesmas untuk membantu mengumpulkan dan verifikasi data kematian maternal.
- Nanti bps kab kota dibekali surat dari bps ri sebagai dasar permintaan data kematian maternal dari dinkes
- yang mengoreksi verifikasi lapangan kematian maternal dari admin supas, sehingga dirancang admin ikut verifikasi ke lapangan
- untuk cek akurasi data PPL dan PML : periksa kematian menurut pendekatan alamat, di MPDN tidak selalu ada alamat rumah tangga yang mengalami kematian maternal, sehingga bisa didekati dari SLS nya

## Evaluasi Dashboard

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%203.png)

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%204.png)

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%205.png)

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%206.png)

![image.png](Pembahasan%20Evaluasi%20Dashboard%20dan%20Mekanisme%20Verifi/image%207.png)

- dalam waktu dekat akan ada pengawasan dari BPS RI dan kementrian terkait
- Pengecekan NIK digunakan untuk mengoreksi penulisan NIK. ini akan jadi penilaian kinerja kepala bps kab kota. Surat nya akan menyusul
- Hati2 dalam penarikan sampel, karena proses salah tarik sampel cukup panjang penyelesaiannya
- Anggaran untuk rapat digunakan untuk rapat dengan dinkes untuk koordinasi mengenai kematian maternal
- Angka kematian ibu hanya bisa estimasi sampek provinsi karena kurangnya sampel yg disebabkan karena pengurangan anggaran, sehingga diperlukan validasi data register dari dinkes untuk memvalidasi data kematian maternal
- Fokus kematian hanya pada kematian maternal. kematian pada anak tidak mempengaruhi penarikan sampel
- Kalo ada kemtian maternal yang ada di MPDN tapi tidak terdata seperti ketinggalan atau kelewat cacah, maka lakukan cek apakah kejadian kematian maternal itu masuk di sampel 16 sampel kita, maka benerin isian form kematian maternal dari admin sesuai pertanyaan yang ada di kues. kalo ternyata tidak masuk sampel, maka biarin aja. karena by sample yg di pilih sudah by design dengan penimbang yg mewakili populasi.