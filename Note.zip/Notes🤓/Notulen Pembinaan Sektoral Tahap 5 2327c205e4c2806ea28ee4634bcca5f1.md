# Notulen Pembinaan Sektoral Tahap 5

Last Edited Time: July 17, 2025 10:32 AM
Activity: Sektoral
Created By: Ahmad Aulia

**Sambutan pak Rudy**

- Setiap OPD memiliki ****tugas dan fungsi masing2, semua OPD memiliki kontribusi yang penting dalam menciptakan
- Dinas kominfo memiliki tupoksi untuk mengkompilasi data dan memvisualisasikan data, sedangkan OPD lain memiliki tupoksi untuk mengumpulkan data sesuai dengan bidang nya masing2

## Tanya Jawab

1. Kenapa kemiskinan bps beda dengan kemiskinan world bank
2. Pengelolaan sdm untuk statistik sektoral ideanya ada statistisi dan prakom, tapi realitas nya 1 orang merangkap jadi prakom dan statistisi
    1. Memulai pembibitan melalui kerja sama dengan polstat stis
3. Bagaimana etika dalam penggunaan big data
    1. pengambilan pengambilan data harus ada izinnya