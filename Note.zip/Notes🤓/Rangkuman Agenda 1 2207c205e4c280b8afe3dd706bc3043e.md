# Rangkuman Agenda 1

Last Edited Time: June 28, 2025 11:42 AM
Activity: Latsar
Created By: Ahmad Aulia

# Wawasan Kebangsaan dan Nilai Bela Negara

## 🧭 I. PENDAHULUAN

Modul ini dirancang agar ASN memahami perannya sebagai:

- Penyelenggara negara yang profesional, bebas KKN, dan netral
- Perekat persatuan dan kesatuan bangsa
- Pelaksana pelayanan publik
- Aktor utama dalam menjaga NKRI berdasarkan Pancasila dan UUD 1945

---

## 🇮🇩 II. WAWASAN KEBANGSAAN

### 🔑 Pengertian:

Wawasan kebangsaan adalah cara pandang bangsa Indonesia tentang kehidupan berbangsa dan bernegara, berdasarkan empat konsensus dasar:

1. **Pancasila**
2. **UUD 1945**
3. **NKRI**
4. **Bhinneka Tunggal Ika**

### 📚 Sejarah Singkat:

- Dimulai dari pergerakan Boedi Oetomo (1908), Sumpah Pemuda (1928), Proklamasi (1945)
- Mengajarkan bahwa bangsa Indonesia lahir dari keberagaman yang disatukan oleh semangat perjuangan dan kesepakatan

### 🧩 Implementasi di BPS Kab/Kota:

- ASN BPS menjaga netralitas politik saat sensus di tahun politik
- Mengedukasi masyarakat tentang pentingnya data statistik untuk kebijakan yang adil bagi seluruh rakyat

---

## 🏛️ III. EMPAT KONSENSUS DASAR BERBANGSA

### 1. **Pancasila**

Dasar negara dan panduan hidup bangsa Indonesia.

**Contoh Implementasi di BPS**:

- ASN menghindari diskriminasi dalam pelayanan publik berdasarkan suku atau agama
- Menjalankan tugas dengan adil sesuai nilai-nilai Pancasila

---

### 2. **UUD 1945**

Konstitusi yang menjamin hak dan kewajiban warga negara serta membatasi kekuasaan.

**Contoh Implementasi di BPS**:

- Menyusun kebijakan internal kantor yang transparan, taat hukum, dan tidak melanggar hak pegawai

---

### 3. **Bhinneka Tunggal Ika**

Semboyan "Berbeda-beda tetapi tetap satu".

**Contoh Implementasi di BPS**:

- Tim kerja terdiri dari ASN lintas suku, gender, dan latar belakang, namun tetap bekerja secara sinergis

---

### 4. **NKRI**

Kesatuan wilayah dan pemerintahan Indonesia yang tak terbagi-bagi.

**Contoh Implementasi di BPS**:

- ASN di daerah perbatasan tetap melayani dengan semangat menjaga keutuhan data nasional
- Bersedia ditugaskan di wilayah terpencil demi integrasi data nasional

---

## 🏳️ IV. SIMBOL KEBANGSAAN

### 🔖 Bendera, Bahasa, Lambang, Lagu Kebangsaan:

- Simbol pemersatu bangsa
- Harus dihormati oleh ASN

**Contoh Implementasi di BPS**:

- ASN ikut upacara bendera rutin dan memperingati hari besar nasional
- Menggunakan Bahasa Indonesia yang baik dan benar dalam komunikasi kedinasan

---

## 🛡️ V. NILAI-NILAI BELA NEGARA

### 🔰 Pengertian:

Bela negara adalah **sikap dan perilaku warga negara dalam menjaga kedaulatan, keutuhan wilayah, dan keselamatan bangsa dan negara**

### 💎 Lima Nilai Dasar Bela Negara:

1. **Cinta Tanah Air**
2. **Sadar Berbangsa dan Bernegara**
3. **Setia pada Pancasila**
4. **Rela Berkorban**
5. **Kemampuan Awal Bela Negara**

---

### 🧪 Implementasi Tiap Nilai di BPS Kab/Kota:

### 1. **Cinta Tanah Air**

> ASN BPS bersedia ditugaskan ke daerah sulit dijangkau saat sensus/survei
> 

### 2. **Sadar Berbangsa dan Bernegara**

> ASN menjaga etika publik, tidak menyebarkan hoaks atau ujaran kebencian
> 

### 3. **Setia pada Pancasila**

> ASN menjalankan tugas dengan berkeadilan dan menghargai keberagaman
> 

### 4. **Rela Berkorban**

> Lembur demi menyelesaikan olah data penting seperti angka kemiskinan atau PDRB
> 

### 5. **Kemampuan Awal Bela Negara**

> ASN terus mengembangkan kompetensi statistik, digital, dan komunikasi untuk menghadapi tantangan nasional
> 

---

## 🧠 VI. KEWASPADAAN DINI & ANCAMAN

### 🔥 Jenis Ancaman:

- Fisik (perang, terorisme)
- Non-fisik (radikalisme, disinformasi, krisis data)
- Alamiah (bencana)

### 🔍 Implementasi Kewaspadaan di BPS:

- Meningkatkan literasi digital ASN agar tidak mudah terpapar hoaks
- Menjaga data dari kebocoran/integritas rendah yang bisa merusak kebijakan publik

---

## 🎯 VII. PENUTUP & RELEVANSI UNTUK ASN BPS

### 🔗 Keterkaitan dengan Tugas ASN:

- Wawasan kebangsaan dan bela negara bukan hanya tanggung jawab TNI/Polri, tapi juga ASN
- ASN BPS adalah pengolah dan penyedia **data strategis nasional** yang digunakan untuk pembangunan, sehingga mereka memiliki **peran penting dalam menjaga stabilitas dan kemajuan bangsa**

### ✅ Rangkuman Peran ASN BPS:

- Pelopor nasionalisme berbasis data
- Penjaga netralitas dan integritas birokrasi
- Pelayan publik yang berwawasan kebangsaan

# Analisis Isu Kontemporer

## 🧭 1. PENDAHULUAN

Modul ini mengajak ASN, khususnya CPNS, untuk:

- Mengenali **perubahan lingkungan strategis** yang memengaruhi birokrasi
- **Berpikir kritis** dalam menghadapi isu-isu strategis
- Meningkatkan **kesiapsiagaan bela negara** melalui pemahaman konteks kekinian

🎯 Tujuannya adalah menciptakan ASN yang mampu **beradaptasi, profesional, dan memiliki integritas** dalam menghadapi tantangan zaman.

---

## 🔁 2. PERUBAHAN LINGKUNGAN STRATEGIS

### ✅ Konsep Perubahan:

Perubahan itu **mutlak**, dan ASN wajib menjadi bagian dari perubahan positif yang bermakna bagi masyarakat.

### 🔑 Komponen ASN Profesional:

- Bertanggung jawab
- Sikap mental positif
- Berorientasi keunggulan
- Kompeten
- Memegang kode etik

### 🧠 Modal Insani yang Harus Dimiliki ASN:

1. **Intelektual**: Peka dan reflektif terhadap perubahan; senang belajar
2. **Emosional**: Mampu mengelola emosi dan membangun hubungan
3. **Sosial**: Mampu bekerja dalam tim dan menjaga harmoni sosial
4. **Ketabahan**: Tidak mudah menyerah (climber mindset)
5. **Etika/Moral**: Integritas dan rasa tanggung jawab
6. **Fisik**: Sehat jasmani untuk menopang kerja produktif

### 💡 Contoh Implementasi di BPS:

- ASN BPS melakukan inovasi dashboard statistik untuk percepatan diseminasi data
- Tetap semangat menyelesaikan survei walau di daerah terpencil
- Menolak gratifikasi saat survei atau interaksi dengan pemerintah daerah

---

## 🔍 3. ISU-ISU STRATEGIS KONTEMPORER

### 🌍 Isu Global dan Nasional yang Relevan:

1. **Korupsi**
2. **Narkoba**
3. **Radikalisme & Terorisme**
4. **Money Laundering**
5. **Proxy War**
6. **Cyber Crime, Hoaks, dan Hate Speech**

> Isu-isu ini membahayakan integritas bangsa dan ketahanan nasional.
> 

---

### 🧨 1. KORUPSI

### 🧬 Sumber: Rakus, moral lemah, gaya hidup konsumtif

### 🧱 Dampak: Melemahkan pelayanan publik, merusak kepercayaan

### 🧰 Solusi: Bangun budaya antikorupsi, transparansi, dan edukasi

**📌 Implementasi di BPS**:

- ASN BPS menolak titipan data palsu dari stakeholder
- Transparansi anggaran survei dan pemanfaatan mitra

---

### 💊 2. NARKOBA

Zat adiktif yang merusak mental, fisik, dan sosial ASN serta generasi muda.

**📌 Implementasi di BPS**:

- ASN BPS ikut sosialisasi anti-narkoba
- Tidak terlibat jaringan atau pemakaian narkotika, meskipun dalam tekanan sosial

---

### 🧨 3. TERORISME & RADIKALISME

### Ciri: Anti-NKRI, intoleran, menolak Pancasila

**📌 Implementasi di BPS**:

- ASN tidak menyebarkan paham radikal di kantor atau media sosial
- Menjalin harmonisasi kerja lintas suku/agama secara aktif

---

### 💰 4. MONEY LAUNDERING

Proses pencucian uang hasil kejahatan → berpotensi masuk ke sistem pemerintah.

**📌 Implementasi di BPS**:

- Teliti dalam verifikasi laporan keuangan dan sumber dana kerja sama statistik daerah
- Menolak hibah atau sponsorship tanpa prosedur resmi

---

### 🛰️ 5. PROXY WAR

Perang tidak langsung melalui media, teknologi, budaya, ekonomi

**📌 Implementasi di BPS**:

- ASN menjaga data dari pengaruh asing, seperti tekanan publikasi angka tertentu
- Tetap menjunjung netralitas dan tidak jadi alat propaganda

---

### 🖥️ 6. CYBER CRIME, HOAX, & HATE SPEECH

Keamanan siber dan penyebaran informasi palsu jadi tantangan berat ASN.

**📌 Implementasi di BPS**:

- ASN BPS bijak dalam bermedia sosial
- Tidak menyebarkan data statistik sebelum dirilis resmi
- Aktif melawan hoaks yang menyudutkan institusi

---

## 🛠️ 4. TEKNIK ANALISIS ISU

### 🔧 Metode Analisis:

1. **Tapisan Isu** → memilih isu yang relevan dan prioritas
2. **Analisis Kesenjangan (Gap Analysis)** → membandingkan kondisi ideal dengan kenyataan
3. **Analisis Fishbone atau Ishikawa** → menggali akar penyebab masalah secara sistematik

### 📌 Implementasi di BPS:

- ASN menganalisis keterlambatan publikasi data dengan fishbone (penyebab: SDM, sistem, anggaran)
- Menyusun rencana perbaikan kerja berdasarkan hasil evaluasi FRA

---

## 🎯 PENUTUP

Modul ini menegaskan bahwa **ASN adalah garda depan pertahanan negara**, terutama di era penuh tantangan digital dan sosial. Dengan memahami isu-isu strategis dan bersikap kritis, ASN dapat:

- Meningkatkan kualitas birokrasi
- Melindungi masyarakat dari ancaman kekinian
- Menjadi pelayan publik yang profesional, adaptif, dan tangguh

---

## 🧾 Kesimpulan Akhir (dalam Konteks ASN BPS Kab/Kota)

| **Nilai/Prinsip** | **Implementasi ASN BPS Kab/Kota** |
| --- | --- |
| Adaptif terhadap perubahan | Meningkatkan skill visualisasi data, literasi digital, dan komunikasi |
| Anti-korupsi | Menolak gratifikasi survei dan tidak memanipulasi data |
| Profesionalisme | Menyusun laporan kegiatan survei yang akurat dan tepat waktu |
| Kritis dan solutif | Menganalisis kendala kerja dengan fishbone untuk perbaikan ke depan |
| Etika dan loyalitas | Menjaga rahasia negara dan data publik hingga waktu rilis resmi |

# Kesiapsiagaan Belanegara

## 🛡️ **1. Pengantar: Apa itu Kesiapsiagaan Bela Negara?**

**Kesiapsiagaan bela negara** adalah **sikap siap fisik, mental, dan sosial** warga negara dalam menjaga dan menjamin keberlangsungan NKRI berdasarkan **Pancasila dan UUD 1945**.

### ⚠️ Kenapa penting?

Karena ancaman terhadap negara kini bersifat **non-fisik**, seperti:

- Disinformasi
- Radikalisme
- Individualisme berlebihan
- Serangan siber
- Krisis sosial dan ekonomi

### 🎯 Tujuan utama untuk ASN:

- **Menjadi pelayan publik yang tangguh dan berintegritas**
- Mampu mengatasi ancaman, gangguan, hambatan, dan tantangan (AGHT)
- Mengamalkan nilai-nilai kebangsaan dalam tugas sehari-hari

---

## 🧭 **2. Nilai-Nilai Dasar Bela Negara**

Modul ini menekankan 6 nilai utama:

| Nilai Dasar | Penjelasan | Implementasi di BPS Kab/Kota |
| --- | --- | --- |
| **1. Cinta Tanah Air** | Kesadaran mencintai dan menjaga Indonesia | ASN BPS tetap semangat bertugas di daerah terpencil atau rawan konflik demi data nasional |
| **2. Kesadaran Berbangsa dan Bernegara** | Tunduk pada aturan, mendukung persatuan | ASN BPS netral dalam politik dan menghormati keberagaman di kantor |
| **3. Yakin pada Pancasila sebagai Ideologi Negara** | Menjadikan Pancasila sebagai pedoman nilai kerja | ASN bekerja jujur, adil, tidak membeda-bedakan responden |
| **4. Rela Berkorban untuk Bangsa dan Negara** | Mengutamakan kepentingan publik di atas pribadi | ASN bersedia lembur menyiapkan publikasi data penting seperti kemiskinan atau IPM |
| **5. Kemampuan Awal Bela Negara** | Jasmani dan mental yang sehat, serta etika kerja | ASN menjaga kebugaran dan mental sehat agar tetap produktif |
| **6. Semangat Mewujudkan Negara Berdaulat, Adil, Makmur** | Dorongan untuk bekerja keras membangun negara | ASN BPS berinovasi meningkatkan kualitas data untuk perencanaan pembangunan |

---

## 💪 **3. Kemampuan Awal Bela Negara**

### a. **Kesehatan Jasmani dan Mental**

- ASN harus sehat fisik agar produktif
- Hindari gaya hidup duduk terus-menerus tanpa olahraga
- Perlu manajemen stres & kendali diri agar tidak emosional dalam bekerja

**Contoh di BPS**:

> ASN menjaga pola makan dan ikut senam pagi kantor, menjaga emosi saat survei menghadapi responden sulit.
> 

---

### b. **Etika, Etiket, dan Moral**

- ASN harus punya **etika pelayanan** dan **sikap santun**
- Hindari konflik, saling menghormati rekan kerja

**Contoh di BPS**:

> Menjawab pertanyaan masyarakat dengan ramah dan tidak menunjukkan sikap superior saat mendampingi OPD dalam forum statistik sektoral.
> 

---

### c. **Kearifan Lokal**

- ASN harus menghargai budaya lokal tempat ia bertugas
- Tidak memaksakan kebiasaan pribadi

**Contoh di BPS**:

> ASN di BPS Papua menghormati adat sebelum turun lapangan, ikut kegiatan masyarakat sebagai bentuk penerimaan sosial.
> 

---

## 🛠️ **4. Rencana Aksi Bela Negara**

ASN wajib menyusun dan menjalankan **Rencana Aksi Bela Negara**, misalnya:

- Kampanye data statistik berbasis literasi digital
- Membuat inovasi pelaporan statistik di desa
- Membangun kesadaran publik tentang pentingnya data melalui edukasi masyarakat

**Contoh di BPS**:

> ASN membuat media sosial literasi data statistik untuk pelajar SMA di daerahnya.
> 

---

## 🧗 **5. Kegiatan Pendukung Kesiapsiagaan**

Pelatihan LATSAR mengandung aktivitas nyata untuk melatih ketahanan dan solidaritas:

- Baris-berbaris dan tata upacara
- Keprotokolan
- Kewaspadaan diri terhadap hoaks
- Latihan kerja tim (team building)
- Caraka malam & api semangat bela negara

**Makna bagi ASN BPS**:

> Melatih kerja sama tim survei, ketahanan mental saat deadline ketat, dan semangat gotong royong dalam kerja kantor.
> 

---

## 📌 **6. Manfaat Kesiapsiagaan Bela Negara**

| Manfaat | Penjelasan |
| --- | --- |
| Disiplin | Teratur dalam pekerjaan dan waktu |
| Kebersamaan | Meningkatkan solidaritas tim |
| Ketahanan mental | Tidak mudah menyerah |
| Patriotisme | Menumbuhkan rasa bangga sebagai ASN pelayan negara |
| Kepemimpinan | Mampu memimpin tim kerja secara efektif |
| Produktivitas | Fisik dan mental lebih siap menghadapi tantangan |

---

## 🧩 **7. Integrasi dengan Modul Lain (Wawasan Kebangsaan & Analisis Isu)**

Modul Kesiapsiagaan Bela Negara menjadi **penerapan nyata** dari:

- **Wawasan kebangsaan (Modul 1)**
- **Analisis isu strategis (Modul 2)**

> Dengan pemahaman nilai kebangsaan dan kemampuan menganalisis isu, ASN jadi siap bela negara melalui aksi nyata sesuai perannya.
> 

---

## ✅ **KESIMPULAN**

Modul ini menegaskan bahwa **bela negara bagi ASN bukan dengan senjata, tapi dengan integritas, etika, pelayanan, dan kerja keras**.

Di BPS Kabupaten/Kota, bela negara berarti:

- Menyediakan data yang valid untuk pembangunan
- Melayani publik dengan hati
- Menjadi pemersatu bangsa melalui netralitas dan integritas