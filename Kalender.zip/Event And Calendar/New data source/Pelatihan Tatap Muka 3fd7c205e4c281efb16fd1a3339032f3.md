# Pelatihan Tatap Muka

Status: Completed
Date: July 23, 2026
Activity: Sakernas

## Jadwal Pertemuan Offline (Fullday)

- **08.00–09.30:** FASIH Pendataan dan praktik penggunaannya
- **09.30–09.45:** Istirahat
- **09.45–11.15:** Role playing (latihan wawancara dan pengisian e-form SAK.AGS26-AK)
- **11.15–12.00:** PPL — pembahasan role playing dan resume seluruh materi; PML — materi pengawasan dan pemeriksaan
- **12.00–13.00:** Istirahat
- **13.30–14.15:** PPL — lanjutan pembahasan role playing dan resume; PML — FASIH Pemeriksaan dan pengkodean
- **14.15–14.30:** Posttest
- **14.30–16.00:** Asynchronous 4 — pendalaman seluruh materi, 30 soal, durasi 90 menit
- **16.00–16.15:** Istirahat
- **16.15–16.45:** Evaluasi dan penutupan