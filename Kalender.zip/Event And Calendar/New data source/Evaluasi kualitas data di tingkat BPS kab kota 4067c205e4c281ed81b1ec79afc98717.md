# Evaluasi kualitas data di tingkat BPS kab/kota

Status: Not Started
Date: November 18, 2026 → December 24, 2026
Activity: Seruti

Sumber: gambar “Jadwal Kegiatan Seruti Triwulan IV 2026”.

Catatan: Jadwal Seruti Triwulan IV 2026.