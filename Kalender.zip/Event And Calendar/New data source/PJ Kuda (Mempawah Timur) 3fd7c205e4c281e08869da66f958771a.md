# PJ Kuda (Mempawah Timur)

Status: Completed
Date: July 17, 2026
Activity: Sensus Ekonomi

**Sumber:** MATRIKS PERJADIN 6104.xlsx

**Kegiatan sesuai matriks:** PJ Kuda (Mempawah Timur)

Tanggal dicatat berdasarkan tanggal dan bulan pada matriks perjalanan dinas. Tahun diinput sebagai 2026 mengikuti konteks jadwal Sensus Ekonomi 2026.