# Pembelajaran Mandiri Hari 1

Status: Completed
Date: August 23, 2026
Activity: Susenas

**Kegiatan:** Pembelajaran mandiri (asynchronous) — 3 JP

**Materi dan tugas:**

- Membaca Buku 4 dan menyimak video ajar kuesioner Susenas.
- Modul Blok I–IV: Keterangan Tempat, Keterangan Pendataan, Ringkasan, dan Demografi.
- Blok V: Nomor Induk Kependudukan dan Pendidikan.
- Blok VI: Kesehatan, Ketenagakerjaan, dan Sarana Angkutan.
- Blok VII: Kepemilikan Sandang, Frekuensi Makan, dan Fasilitas Tidur.
- Blok VIII.A: Keterangan untuk Balita.
- Blok VIII.B: Perkembangan Anak Umur 24–59 Bulan.
- Blok IX: Kebersamaan; Blok X: Akses Media.
- Blok XV: Perumahan dan Persampahan; Blok XVI: Perubahan Iklim dan Bencana.
- Mengerjakan kuis sebanyak 10 soal dari materi tersebut.