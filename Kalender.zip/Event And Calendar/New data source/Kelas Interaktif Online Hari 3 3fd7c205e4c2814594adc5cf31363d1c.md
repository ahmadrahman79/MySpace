# Kelas Interaktif Online Hari 3

Status: Completed
Date: August 25, 2026
Activity: Susenas

**Kegiatan:** Kelas interaktif online-2 dan pembelajaran mandiri asynchronous.

**Jadwal kelas interaktif:**

- 08.30–09.15: Blok XVII (Perlindungan Sosial) dan diskusi materi pembelajaran mandiri.
- 09.15–10.00: Materi Susenas KP Blok I–IV.1.
- 10.00–10.15: Istirahat.
- 10.15–11.00: Materi Susenas KP Blok IV.2 dan IV.3.

**Pembelajaran mandiri setelah kelas (3 JP):** membaca Buku 4 dan menyimak video ajar Kuesioner Susenas KP dan Seruti, meliputi materi Susenas KP Blok V–VIII dan materi Seruti. Mengerjakan kuis 5 soal.