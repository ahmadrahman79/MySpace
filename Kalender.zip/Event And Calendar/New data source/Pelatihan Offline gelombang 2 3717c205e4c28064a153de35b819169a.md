# Pelatihan Offline gelombang 2

Status: Completed
Date: June 10, 2026 → June 12, 2026
Activity: Sensus Ekonomi

## Content overview

Provide 2-3 sentences describing the content.

## ToDos

- [ ]  
- [ ]  
- [ ]  

## Notes

- 
- 
- 

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)