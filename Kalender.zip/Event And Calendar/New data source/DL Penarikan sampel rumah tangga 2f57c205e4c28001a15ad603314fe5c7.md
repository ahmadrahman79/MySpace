# DL Penarikan sampel rumah tangga

Status: Completed
Date: January 30, 2026
Activity: Susenas