# PJJ Hari 1

Status: Completed
Date: July 20, 2026
Activity: Sakernas

## Jadwal PJJ (Pertemuan Online)

- **08.30–09.00:** Pembukaan
- **09.00–09.15:** Pretest
- **09.15–10.45:** Materi pendahuluan — penjelasan teknis Sakernas Agustus 2026, organisasi lapangan, prosedur pendataan rumah tangga, dan tata cara pengisian e-form
- **10.45–11.00:** Istirahat
- **11.00–12.30:** Pemutakhiran dan penarikan sampel Sakernas Agustus 2026
- **12.30–13.30:** Istirahat
- **13.30–14.15:** Asynchronous 1 — 15 soal materi PJJ Hari I, durasi 45 menit
- **14.15–15.45:** Belajar mandiri materi PJJ Hari II: Buku Pedoman Pendataan Bab III (3.1 dan 3.2) dan Bab VI (Modul 1–10), E-form SAK.AGS26-AK, E-form SAK.AGS26-P, serta bahan ajar 4, 5, dan 10–19.