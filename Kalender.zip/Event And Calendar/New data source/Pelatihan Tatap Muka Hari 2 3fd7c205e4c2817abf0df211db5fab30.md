# Pelatihan Tatap Muka Hari 2

Status: Completed
Date: August 27, 2026
Activity: Susenas

**Kegiatan:** Pelatihan luar jaringan (tatap muka), Hari II.

**Jadwal:**

- 08.00–08.45: Reviu materi Susenas Modul oleh Innas, terutama materi kelas online.
- 08.45–09.30: Materi Susenas KP Blok V–VIII.
- 09.30–10.15: Reviu materi Susenas KP oleh Innas, terutama materi kelas online.
- 10.15–10.30: Istirahat.
- 10.30–11.15: Materi VSERUTI26.INTI Blok I–IV.3.
- 11.15–12.00: Materi VSERUTI26.INTI Blok V–VII.
- 12.00–13.00: Istirahat.
- 13.00–13.45: Lanjutan materi VSERUTI26.INTI Blok V–VII.
- 13.45–15.15: Role playing; Innas memberi penjelasan dan masukan kepada peserta.
- 15.15–15.45: Istirahat.
- 15.45–16.30: Diskusi strategi pendataan dipimpin Innas.
- 16.30–17.15: Posttest dan evaluasi materi (asynchronous).
- 17.15–17.45: Penutupan.

**Total pada rancangan:** 10 JP asynchronous, 27 JP synchronous, total 37 JP.