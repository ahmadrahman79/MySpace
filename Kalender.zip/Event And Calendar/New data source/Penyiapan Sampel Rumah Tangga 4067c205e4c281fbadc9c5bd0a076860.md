# Penyiapan Sampel Rumah Tangga

Status: Not Started
Date: October 26, 2026 → November 13, 2026
Activity: Sakernas

Sumber: 01.10.2026_JADWAL SAKERNAS NOVEMBER 2026.docx
Periode pada dokumen: 26 Oktober – 13 November 2026
Status awal: Not Started (belum dikonfirmasi selesai).