# Pembelajaran Mandiri Hari 1

Status: Completed
Date: July 17, 2026
Activity: Sakernas

## Jadwal

Pembelajaran mandiri calon petugas PPL dan PML.

**Materi:**

- Buku Pedoman Pendataan Bab I, II, IV, V, dan Bab VI hingga Modul 5
- Daftar SAK.AGS26-P
- Daftar SAK.AGS26-DSRT
- Daftar SAK.AGS26-DSSLS
- Kuesioner SAK.AGS26-AK
- Bahan ajar 1, 3, 5, 7, 8, 9, dan 10–14

**Tugas mandiri MOOC 1:** mengerjakan 15 soal terkait materi hari pertama, durasi maksimal 45 menit, paling lambat pukul 16.00.