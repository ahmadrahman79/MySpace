# Pembelajaran Mandiri Hari 3

Status: Completed
Date: July 19, 2026
Activity: Sakernas

## Jadwal

Pembelajaran mandiri calon petugas PPL dan PML.

**Materi PPL dan PML:**

- Buku Pedoman Pendataan Bab III
- E-form SAK.AGS26-AK
- Bahan ajar 4 dan 33

**Tambahan materi untuk PML:** Buku Pedoman Pemeriksaan serta bahan ajar 35 dan 36.

**Praktik MOOC 3:** calon petugas PPL mempraktikkan pengisian e-form SAK.AGS26-AK berdasarkan informasi rumah tangga sendiri atau tetangga/saudara terdekat. Screenshot hasil pengisian FASIH Pendataan dengan status *Submitted by PPL* dikirim ke WAG peserta atau tautan yang disediakan penyelenggara paling lambat pukul 16.00. Calon petugas PML juga berlatih memeriksa dan mengodekan e-form yang telah disubmit PPL.