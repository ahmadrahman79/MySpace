# Pelatihan Tatap Muka Hari 1

Status: Completed
Date: August 26, 2026
Activity: Susenas

**Kegiatan:** Pelatihan luar jaringan (tatap muka), Hari I.

**Jadwal:**

- 08.00–08.30: Pembukaan dan pendahuluan.
- 08.30–10.00: Penjelasan umum Susenas September 2026, metodologi Susenas September 2026, dan daftar sampel rumah tangga (materi pemutakhiran rumah tangga).
- 10.00–10.15: Istirahat.
- 10.15–11.45: Blok VIII.A (Keterangan untuk Balita) dan Blok VIII.B (Perkembangan Anak Umur 24–59 Bulan).
- 11.45–12.45: Istirahat.
- 12.45–13.30: Blok IX (Kebersamaan) dan Blok X (Akses Media).
- 13.30–15.00: Blok XII (Olahraga, Kebudayaan, dan Organisasi) serta Blok XIII (Hubungan Sosial Kemasyarakatan).
- 15.00–15.30: Istirahat.
- 15.30–16.15: Blok XI (Program Makan Bergizi Gratis/MBG).
- 16.15–17.00: Blok XIV bagian A (Kebudayaan) dan B (Wawasan Kebangsaan).
- 17.00–17.45: Blok XIV bagian C (Kerukunan/Toleransi) dan D (Perilaku Masyarakat Bersih, Tertib, serta Keamanan Lingkungan).