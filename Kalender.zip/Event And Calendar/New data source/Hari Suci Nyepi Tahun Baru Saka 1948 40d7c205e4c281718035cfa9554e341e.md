# Hari Suci Nyepi Tahun Baru Saka 1948

Status: Not Started
Date: March 19, 2026
Activity: Libur Nasional