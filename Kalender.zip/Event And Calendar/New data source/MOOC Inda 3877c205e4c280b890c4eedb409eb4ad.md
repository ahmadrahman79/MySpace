# MOOC Inda

Status: Completed
Date: July 1, 2026 → July 3, 2026
Activity: Sakernas

## Content overview

Provide 2-3 sentences describing the content.

## ToDos

- [ ]  
- [ ]  
- [ ]  

## Notes

- 
- 
- 

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)