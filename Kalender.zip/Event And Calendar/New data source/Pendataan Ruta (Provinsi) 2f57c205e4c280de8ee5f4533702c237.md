# Pendataan Ruta (Provinsi)

Status: Completed
Date: January 31, 2026 → February 16, 2026
Activity: Susenas