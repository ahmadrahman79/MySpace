# PJJ Hari 2

Status: Completed
Date: July 21, 2026
Activity: Sakernas

## Jadwal PJJ (Pertemuan Online)

- **08.30–10.00:** FASIH Mobile dan FASIH Pemutakhiran
- **10.00–10.15:** Istirahat
- **10.15–12.30:** Materi SAK.AGS26-AK, Modul 1–10
- **12.30–13.30:** Istirahat
- **13.30–14.15:** Asynchronous 2 — 15 soal materi PJJ Hari II, durasi 45 menit
- **14.15–15.45:** Belajar mandiri materi PJJ Hari III: Buku Pedoman Pendataan Bab VI Modul 11–23, E-form SAK.AGS26-AK, serta bahan ajar 20–32 dan 34.