# Pemutakhiran rumah tangga pada SLS

Status: Completed
Date: January 21, 2026 → January 27, 2026
Activity: Susenas