# Pemutakhiran Mempawah Hilir

Status: Not Started
Activity: Sakernas

Jadwal kegiatan Sakernas bulan Mei 2026.