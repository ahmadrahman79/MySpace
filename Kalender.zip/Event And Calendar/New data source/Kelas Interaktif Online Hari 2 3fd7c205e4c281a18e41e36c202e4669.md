# Kelas Interaktif Online Hari 2

Status: Completed
Date: August 24, 2026
Activity: Susenas

**Kegiatan:** Kelas interaktif online-1 dan pembelajaran mandiri asynchronous.

**Jadwal kelas interaktif:**

- 08.00–08.30: Pembukaan dan pretest.
- 08.30–09.15: Blok I–IV (Tempat, Pendataan, Ringkasan, Demografi) dan Blok V (NIK dan Pendidikan).
- 09.15–10.00: Blok VI (Kesehatan, Ketenagakerjaan, Sarana Angkutan) dan Blok VII (Kepemilikan Sandang, Frekuensi Makan, Fasilitas Tidur).
- 10.00–10.15: Istirahat.
- 10.15–11.00: Blok XV (Perumahan dan Persampahan).
- 11.00–12.30: Blok XVI (Perubahan Iklim dan Bencana).

**Pembelajaran mandiri setelah kelas (3 JP):** membaca Buku 4 dan menyimak video ajar Kuesioner Susenas Modul dan Susenas KP: Blok XI (Program Makan Bergizi Gratis/MBG), Blok XII (Olahraga, Kebudayaan, dan Organisasi), Blok XIII (Hubungan Sosial Kemasyarakatan), Blok XIV bagian A–D (Kebudayaan, Wawasan Kebangsaan, Kerukunan/Toleransi, Perilaku Masyarakat Bersih dan Tertib serta Keamanan Lingkungan), Blok XVII (Perlindungan Sosial), serta Susenas KP Blok IV.1, IV.2, dan IV.3. Mengerjakan kuis 10 soal.