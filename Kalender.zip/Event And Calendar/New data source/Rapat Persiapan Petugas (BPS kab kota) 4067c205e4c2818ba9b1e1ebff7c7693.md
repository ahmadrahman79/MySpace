# Rapat Persiapan Petugas (BPS kab/kota)

Status: Not Started
Date: November 1, 2026 → November 14, 2026
Activity: Seruti

Sumber: gambar “Jadwal Kegiatan Seruti Triwulan IV 2026”.

Catatan: Pekan I–II November 2026; rentang tanggal ditafsirkan sebagai 1–14 November.