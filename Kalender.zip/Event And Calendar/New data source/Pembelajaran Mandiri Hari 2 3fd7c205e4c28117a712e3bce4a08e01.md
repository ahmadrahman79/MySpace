# Pembelajaran Mandiri Hari 2

Status: Completed
Date: July 18, 2026
Activity: Sakernas

## Jadwal

Pembelajaran mandiri calon petugas PPL dan PML.

**Materi:**

- Buku Pedoman Pendataan Bab VI, Modul 6–23
- E-form SAK.AGS26-AK
- Bahan ajar 15–32 dan 34

**Tugas mandiri MOOC 2:** mengerjakan 15 soal terkait materi hari kedua, durasi maksimal 45 menit, paling lambat pukul 16.00.