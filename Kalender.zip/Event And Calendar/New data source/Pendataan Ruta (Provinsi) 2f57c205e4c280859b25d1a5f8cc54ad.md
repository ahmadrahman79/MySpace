# Pendataan Ruta (Provinsi)

Status: Completed
Date: February 1, 2026 → February 10, 2026
Activity: Seruti