# Pendataan Rumah Tangga Sampel

Status: Not Started
Date: November 8, 2026 → November 27, 2026
Activity: Sakernas

Sumber: 01.10.2026_JADWAL SAKERNAS NOVEMBER 2026.docx
Periode pada dokumen: 8 – 27 November 2026
Status awal: Not Started (belum dikonfirmasi selesai).