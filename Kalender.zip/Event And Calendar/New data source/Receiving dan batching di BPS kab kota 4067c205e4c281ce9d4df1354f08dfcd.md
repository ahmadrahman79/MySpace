# Receiving dan batching di BPS kab/kota

Status: Not Started
Date: November 14, 2026 → December 10, 2026
Activity: Seruti

Sumber: gambar “Jadwal Kegiatan Seruti Triwulan IV 2026”.

Catatan: Jadwal Seruti Triwulan IV 2026.