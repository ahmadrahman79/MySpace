# Pendataan dan pemeriksaan pendataan Ruta SNKLIK

Status: Completed
Date: February 4, 2026 → February 18, 2026
Activity: SNLIK