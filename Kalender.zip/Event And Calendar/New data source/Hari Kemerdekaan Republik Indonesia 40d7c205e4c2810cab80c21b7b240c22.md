# Hari Kemerdekaan Republik Indonesia

Status: Not Started
Date: August 17, 2026
Activity: Libur Nasional