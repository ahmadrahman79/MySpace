# Pendataan lapangan (versi provinsi)

Status: Completed
Date: February 8, 2026 → February 25, 2026
Activity: Sakernas